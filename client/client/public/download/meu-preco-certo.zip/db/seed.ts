import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    // seed data here
    }
 catch (error) {
    console.error(error);
  }
}

seed();
