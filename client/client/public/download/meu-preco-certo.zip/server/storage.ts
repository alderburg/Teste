import { 
  users, produtos, servicos, itensAluguel, fornecedores, marketplaces, custos, despesas, taxas, tributos, precificacoes, categorias,
  type User, type InsertUser, 
  type Produto, type InsertProduto,
  type Servico, type InsertServico,
  type ItemAluguel, type InsertItemAluguel,
  type Fornecedor, type InsertFornecedor,
  type Marketplace, type InsertMarketplace,
  type Custo, type InsertCusto,
  type Despesa, type InsertDespesa,
  type Taxa, type InsertTaxa,
  type Tributo, type InsertTributo,
  type Precificacao, type InsertPrecificacao,
  type Categoria, type InsertCategoria
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // Usuários
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Produtos
  getProduto(id: number): Promise<Produto | undefined>;
  getProdutos(userId: number, tipo?: string): Promise<Produto[]>;
  createProduto(produto: InsertProduto): Promise<Produto>;
  updateProduto(id: number, produto: Partial<Produto>): Promise<Produto | undefined>;
  deleteProduto(id: number): Promise<boolean>;
  
  // Serviços
  getServico(id: number): Promise<Servico | undefined>;
  getServicos(userId: number): Promise<Servico[]>;
  createServico(servico: InsertServico): Promise<Servico>;
  updateServico(id: number, servico: Partial<Servico>): Promise<Servico | undefined>;
  deleteServico(id: number): Promise<boolean>;
  
  // Itens para Aluguel
  getItemAluguel(id: number): Promise<ItemAluguel | undefined>;
  getItensAluguel(userId: number): Promise<ItemAluguel[]>;
  createItemAluguel(item: InsertItemAluguel): Promise<ItemAluguel>;
  updateItemAluguel(id: number, item: Partial<ItemAluguel>): Promise<ItemAluguel | undefined>;
  deleteItemAluguel(id: number): Promise<boolean>;
  
  // Fornecedores
  getFornecedor(id: number): Promise<Fornecedor | undefined>;
  getFornecedores(userId: number): Promise<Fornecedor[]>;
  createFornecedor(fornecedor: InsertFornecedor): Promise<Fornecedor>;
  updateFornecedor(id: number, fornecedor: Partial<Fornecedor>): Promise<Fornecedor | undefined>;
  deleteFornecedor(id: number): Promise<boolean>;
  
  // Clientes
  getCliente(id: number): Promise<Cliente | undefined>;
  getClientes(userId: number): Promise<Cliente[]>;
  createCliente(cliente: InsertCliente): Promise<Cliente>;
  updateCliente(id: number, cliente: Partial<Cliente>): Promise<Cliente | undefined>;
  deleteCliente(id: number): Promise<boolean>;
  
  // Marketplaces
  getMarketplace(id: number): Promise<Marketplace | undefined>;
  getMarketplaces(userId: number): Promise<Marketplace[]>;
  createMarketplace(marketplace: InsertMarketplace): Promise<Marketplace>;
  updateMarketplace(id: number, marketplace: Partial<Marketplace>): Promise<Marketplace | undefined>;
  deleteMarketplace(id: number): Promise<boolean>;
  
  // Categorias
  getCategoria(id: number): Promise<Categoria | undefined>;
  getCategorias(userId: number, tipo?: string): Promise<Categoria[]>;
  createCategoria(categoria: InsertCategoria): Promise<Categoria>;
  updateCategoria(id: number, categoria: Partial<Categoria>): Promise<Categoria | undefined>;
  deleteCategoria(id: number): Promise<boolean>;
  
  // Custos
  getCusto(id: number): Promise<Custo | undefined>;
  getCustos(userId: number, tipo?: string): Promise<Custo[]>;
  createCusto(custo: InsertCusto): Promise<Custo>;
  updateCusto(id: number, custo: Partial<Custo>): Promise<Custo | undefined>;
  deleteCusto(id: number): Promise<boolean>;
  
  // Despesas
  getDespesa(id: number): Promise<Despesa | undefined>;
  getDespesas(userId: number, tipo?: string, categoria?: string): Promise<Despesa[]>;
  createDespesa(despesa: InsertDespesa): Promise<Despesa>;
  updateDespesa(id: number, despesa: Partial<Despesa>): Promise<Despesa | undefined>;
  deleteDespesa(id: number): Promise<boolean>;
  
  // Taxas
  getTaxa(id: number): Promise<Taxa | undefined>;
  getTaxas(userId: number, tipo?: string): Promise<Taxa[]>;
  createTaxa(taxa: InsertTaxa): Promise<Taxa>;
  updateTaxa(id: number, taxa: Partial<Taxa>): Promise<Taxa | undefined>;
  deleteTaxa(id: number): Promise<boolean>;
  
  // Tributos
  getTributo(id: number): Promise<Tributo | undefined>;
  getTributos(userId: number): Promise<Tributo[]>;
  createTributo(tributo: InsertTributo): Promise<Tributo>;
  updateTributo(id: number, tributo: Partial<Tributo>): Promise<Tributo | undefined>;
  deleteTributo(id: number): Promise<boolean>;
  
  // Precificações
  getPrecificacao(id: number): Promise<Precificacao | undefined>;
  getPrecificacoes(userId: number, tipo?: string): Promise<Precificacao[]>;
  createPrecificacao(precificacao: InsertPrecificacao): Promise<Precificacao>;
  updatePrecificacao(id: number, precificacao: Partial<Precificacao>): Promise<Precificacao | undefined>;
  deletePrecificacao(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // Na verdade vamos implementar o DatabaseStorage simulando uso do banco,
  // mas mantendo os dados em memória para facilitar o desenvolvimento
  private users: Map<number, User>;
  private produtos: Map<number, Produto>;
  private servicos: Map<number, Servico>;
  private itensAluguel: Map<number, ItemAluguel>;
  private fornecedores: Map<number, Fornecedor>;
  private clientes: Map<number, Cliente>;
  private marketplaces: Map<number, Marketplace>;
  private categorias: Map<number, Categoria>;
  private custos: Map<number, Custo>;
  private despesas: Map<number, Despesa>;
  private taxas: Map<number, Taxa>;
  private tributos: Map<number, Tributo>;
  private precificacoes: Map<number, Precificacao>;

  private userIdCounter: number;
  private produtoIdCounter: number;
  private servicoIdCounter: number;
  private itemAluguelIdCounter: number;
  private fornecedorIdCounter: number;
  private clienteIdCounter: number;
  private marketplaceIdCounter: number;
  private categoriaIdCounter: number;
  private custoIdCounter: number;
  private despesaIdCounter: number;
  private taxaIdCounter: number;
  private tributoIdCounter: number;
  private precificacaoIdCounter: number;

  constructor() {
    // Inicializa os Maps
    this.users = new Map();
    this.produtos = new Map();
    this.servicos = new Map();
    this.itensAluguel = new Map();
    this.fornecedores = new Map();
    this.clientes = new Map();
    this.marketplaces = new Map();
    this.categorias = new Map();
    this.custos = new Map();
    this.despesas = new Map();
    this.taxas = new Map();
    this.tributos = new Map();
    this.precificacoes = new Map();

    // Inicializa os contadores de ID
    this.userIdCounter = 1;
    this.produtoIdCounter = 1;
    this.servicoIdCounter = 1;
    this.itemAluguelIdCounter = 1;
    this.fornecedorIdCounter = 1;
    this.clienteIdCounter = 1;
    this.marketplaceIdCounter = 1;
    this.categoriaIdCounter = 1;
    this.custoIdCounter = 1;
    this.despesaIdCounter = 1;
    this.taxaIdCounter = 1;
    this.tributoIdCounter = 1;
    this.precificacaoIdCounter = 1;
  }

  // Métodos para Usuários
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Métodos para Produtos
  async getProduto(id: number): Promise<Produto | undefined> {
    return this.produtos.get(id);
  }

  async getProdutos(userId: number, tipo?: string): Promise<Produto[]> {
    return Array.from(this.produtos.values()).filter((produto) => {
      if (userId && produto.userId !== userId) return false;
      if (tipo && produto.tipo !== tipo) return false;
      return true;
    });
  }

  async createProduto(produto: InsertProduto): Promise<Produto> {
    const id = this.produtoIdCounter++;
    const now = new Date();
    const novoProduto = { 
      ...produto, 
      id, 
      createdAt: now, 
      updatedAt: now,
    };
    this.produtos.set(id, novoProduto);
    return novoProduto;
  }

  async updateProduto(id: number, produto: Partial<Produto>): Promise<Produto | undefined> {
    const existingProduto = this.produtos.get(id);
    if (!existingProduto) return undefined;

    const updatedProduto = {
      ...existingProduto,
      ...produto,
      updatedAt: new Date(),
    };
    this.produtos.set(id, updatedProduto);
    return updatedProduto;
  }

  async deleteProduto(id: number): Promise<boolean> {
    return this.produtos.delete(id);
  }

  // Métodos para Serviços
  async getServico(id: number): Promise<Servico | undefined> {
    return this.servicos.get(id);
  }

  async getServicos(userId: number): Promise<Servico[]> {
    return Array.from(this.servicos.values()).filter((servico) => 
      servico.userId === userId
    );
  }

  async createServico(servico: InsertServico): Promise<Servico> {
    const id = this.servicoIdCounter++;
    const now = new Date();
    const novoServico = { 
      ...servico, 
      id, 
      createdAt: now, 
      updatedAt: now,
    };
    this.servicos.set(id, novoServico);
    return novoServico;
  }

  async updateServico(id: number, servico: Partial<Servico>): Promise<Servico | undefined> {
    const existingServico = this.servicos.get(id);
    if (!existingServico) return undefined;

    const updatedServico = {
      ...existingServico,
      ...servico,
      updatedAt: new Date(),
    };
    this.servicos.set(id, updatedServico);
    return updatedServico;
  }

  async deleteServico(id: number): Promise<boolean> {
    return this.servicos.delete(id);
  }

  // Métodos para Itens de Aluguel
  async getItemAluguel(id: number): Promise<ItemAluguel | undefined> {
    return this.itensAluguel.get(id);
  }

  async getItensAluguel(userId: number): Promise<ItemAluguel[]> {
    return Array.from(this.itensAluguel.values()).filter((item) => 
      item.userId === userId
    );
  }

  async createItemAluguel(item: InsertItemAluguel): Promise<ItemAluguel> {
    const id = this.itemAluguelIdCounter++;
    const now = new Date();
    const novoItem = { 
      ...item, 
      id, 
      createdAt: now, 
      updatedAt: now,
    };
    this.itensAluguel.set(id, novoItem);
    return novoItem;
  }

  async updateItemAluguel(id: number, item: Partial<ItemAluguel>): Promise<ItemAluguel | undefined> {
    const existingItem = this.itensAluguel.get(id);
    if (!existingItem) return undefined;

    const updatedItem = {
      ...existingItem,
      ...item,
      updatedAt: new Date(),
    };
    this.itensAluguel.set(id, updatedItem);
    return updatedItem;
  }

  async deleteItemAluguel(id: number): Promise<boolean> {
    return this.itensAluguel.delete(id);
  }

  // Métodos para Fornecedores
  async getFornecedor(id: number): Promise<Fornecedor | undefined> {
    return this.fornecedores.get(id);
  }

  async getFornecedores(userId: number): Promise<Fornecedor[]> {
    return Array.from(this.fornecedores.values()).filter((fornecedor) => 
      fornecedor.userId === userId
    );
  }

  async createFornecedor(fornecedor: InsertFornecedor): Promise<Fornecedor> {
    const id = this.fornecedorIdCounter++;
    const now = new Date();
    const novoFornecedor = { 
      ...fornecedor, 
      id, 
      createdAt: now, 
      updatedAt: now,
    };
    this.fornecedores.set(id, novoFornecedor);
    return novoFornecedor;
  }

  async updateFornecedor(id: number, fornecedor: Partial<Fornecedor>): Promise<Fornecedor | undefined> {
    const existingFornecedor = this.fornecedores.get(id);
    if (!existingFornecedor) return undefined;

    const updatedFornecedor = {
      ...existingFornecedor,
      ...fornecedor,
      updatedAt: new Date(),
    };
    this.fornecedores.set(id, updatedFornecedor);
    return updatedFornecedor;
  }

  async deleteFornecedor(id: number): Promise<boolean> {
    return this.fornecedores.delete(id);
  }
  
  // Métodos para Clientes
  async getCliente(id: number): Promise<Cliente | undefined> {
    return this.clientes.get(id);
  }

  async getClientes(userId: number): Promise<Cliente[]> {
    return Array.from(this.clientes.values()).filter((cliente) => 
      cliente.userId === userId
    );
  }

  async createCliente(cliente: InsertCliente): Promise<Cliente> {
    const id = this.clienteIdCounter++;
    const now = new Date();
    const novoCliente = { 
      ...cliente, 
      id, 
      createdAt: now, 
      updatedAt: now,
    };
    this.clientes.set(id, novoCliente);
    return novoCliente;
  }

  async updateCliente(id: number, cliente: Partial<Cliente>): Promise<Cliente | undefined> {
    const existingCliente = this.clientes.get(id);
    if (!existingCliente) return undefined;

    const updatedCliente = {
      ...existingCliente,
      ...cliente,
      updatedAt: new Date(),
    };
    this.clientes.set(id, updatedCliente);
    return updatedCliente;
  }

  async deleteCliente(id: number): Promise<boolean> {
    return this.clientes.delete(id);
  }

  // Métodos para Marketplaces
  async getMarketplace(id: number): Promise<Marketplace | undefined> {
    return this.marketplaces.get(id);
  }

  async getMarketplaces(userId: number): Promise<Marketplace[]> {
    return Array.from(this.marketplaces.values()).filter((marketplace) => 
      marketplace.userId === userId
    );
  }

  async createMarketplace(marketplace: InsertMarketplace): Promise<Marketplace> {
    const id = this.marketplaceIdCounter++;
    const now = new Date();
    const novoMarketplace = { 
      ...marketplace, 
      id, 
      createdAt: now, 
      updatedAt: now,
    };
    this.marketplaces.set(id, novoMarketplace);
    return novoMarketplace;
  }

  async updateMarketplace(id: number, marketplace: Partial<Marketplace>): Promise<Marketplace | undefined> {
    const existingMarketplace = this.marketplaces.get(id);
    if (!existingMarketplace) return undefined;

    const updatedMarketplace = {
      ...existingMarketplace,
      ...marketplace,
      updatedAt: new Date(),
    };
    this.marketplaces.set(id, updatedMarketplace);
    return updatedMarketplace;
  }

  async deleteMarketplace(id: number): Promise<boolean> {
    return this.marketplaces.delete(id);
  }

  // Métodos para Categorias
  async getCategoria(id: number): Promise<Categoria | undefined> {
    return this.categorias.get(id);
  }

  async getCategorias(userId: number, tipo?: string): Promise<Categoria[]> {
    return Array.from(this.categorias.values()).filter((categoria) => {
      if (userId && categoria.userId !== userId) return false;
      if (tipo && categoria.tipo !== tipo) return false;
      return true;
    });
  }

  async createCategoria(categoria: InsertCategoria): Promise<Categoria> {
    const id = this.categoriaIdCounter++;
    const now = new Date();
    const novaCategoria: Categoria = { 
      id, 
      nome: categoria.nome,
      descricao: categoria.descricao ?? null,
      tipo: categoria.tipo,
      userId: categoria.userId ?? null,
      ordem: categoria.ordem ?? null,
      ativa: categoria.ativa ?? null,
      createdAt: now, 
      updatedAt: now,
    };
    this.categorias.set(id, novaCategoria);
    return novaCategoria;
  }

  async updateCategoria(id: number, categoria: Partial<Categoria>): Promise<Categoria | undefined> {
    const existingCategoria = this.categorias.get(id);
    if (!existingCategoria) return undefined;

    const updatedCategoria = {
      ...existingCategoria,
      ...categoria,
      updatedAt: new Date(),
    };
    this.categorias.set(id, updatedCategoria);
    return updatedCategoria;
  }

  async deleteCategoria(id: number): Promise<boolean> {
    return this.categorias.delete(id);
  }

  // Métodos para Custos
  async getCusto(id: number): Promise<Custo | undefined> {
    return this.custos.get(id);
  }

  async getCustos(userId: number, tipo?: string): Promise<Custo[]> {
    return Array.from(this.custos.values()).filter((custo) => {
      if (userId && custo.userId !== userId) return false;
      if (tipo && custo.tipo !== tipo) return false;
      return true;
    });
  }

  async createCusto(custo: InsertCusto): Promise<Custo> {
    const id = this.custoIdCounter++;
    const now = new Date();
    const novoCusto = { 
      ...custo, 
      id, 
      createdAt: now, 
      updatedAt: now,
    };
    this.custos.set(id, novoCusto);
    return novoCusto;
  }

  async updateCusto(id: number, custo: Partial<Custo>): Promise<Custo | undefined> {
    const existingCusto = this.custos.get(id);
    if (!existingCusto) return undefined;

    const updatedCusto = {
      ...existingCusto,
      ...custo,
      updatedAt: new Date(),
    };
    this.custos.set(id, updatedCusto);
    return updatedCusto;
  }

  async deleteCusto(id: number): Promise<boolean> {
    return this.custos.delete(id);
  }

  // Métodos para Despesas
  async getDespesa(id: number): Promise<Despesa | undefined> {
    return this.despesas.get(id);
  }

  async getDespesas(userId: number, tipo?: string, categoria?: string): Promise<Despesa[]> {
    return Array.from(this.despesas.values()).filter((despesa) => {
      if (userId && despesa.userId !== userId) return false;
      if (tipo && despesa.tipo !== tipo) return false;
      if (categoria && despesa.categoria !== categoria) return false;
      return true;
    });
  }

  async createDespesa(despesa: InsertDespesa): Promise<Despesa> {
    const id = this.despesaIdCounter++;
    const now = new Date();
    const novaDespesa = { 
      ...despesa, 
      id, 
      createdAt: now, 
      updatedAt: now,
    };
    this.despesas.set(id, novaDespesa);
    return novaDespesa;
  }

  async updateDespesa(id: number, despesa: Partial<Despesa>): Promise<Despesa | undefined> {
    const existingDespesa = this.despesas.get(id);
    if (!existingDespesa) return undefined;

    const updatedDespesa = {
      ...existingDespesa,
      ...despesa,
      updatedAt: new Date(),
    };
    this.despesas.set(id, updatedDespesa);
    return updatedDespesa;
  }

  async deleteDespesa(id: number): Promise<boolean> {
    return this.despesas.delete(id);
  }

  // Métodos para Taxas
  async getTaxa(id: number): Promise<Taxa | undefined> {
    return this.taxas.get(id);
  }

  async getTaxas(userId: number, tipo?: string): Promise<Taxa[]> {
    return Array.from(this.taxas.values()).filter((taxa) => {
      if (userId && taxa.userId !== userId) return false;
      if (tipo && taxa.tipo !== tipo) return false;
      return true;
    });
  }

  async createTaxa(taxa: InsertTaxa): Promise<Taxa> {
    const id = this.taxaIdCounter++;
    const now = new Date();
    const novaTaxa = { 
      ...taxa, 
      id, 
      createdAt: now, 
      updatedAt: now,
    };
    this.taxas.set(id, novaTaxa);
    return novaTaxa;
  }

  async updateTaxa(id: number, taxa: Partial<Taxa>): Promise<Taxa | undefined> {
    const existingTaxa = this.taxas.get(id);
    if (!existingTaxa) return undefined;

    const updatedTaxa = {
      ...existingTaxa,
      ...taxa,
      updatedAt: new Date(),
    };
    this.taxas.set(id, updatedTaxa);
    return updatedTaxa;
  }

  async deleteTaxa(id: number): Promise<boolean> {
    return this.taxas.delete(id);
  }

  // Métodos para Tributos
  async getTributo(id: number): Promise<Tributo | undefined> {
    return this.tributos.get(id);
  }

  async getTributos(userId: number): Promise<Tributo[]> {
    return Array.from(this.tributos.values()).filter((tributo) => 
      tributo.userId === userId || tributo.userId === null
    );
  }

  async createTributo(tributo: InsertTributo): Promise<Tributo> {
    const id = this.tributoIdCounter++;
    const now = new Date();
    const novoTributo = { 
      ...tributo, 
      id, 
      createdAt: now, 
      updatedAt: now,
    };
    this.tributos.set(id, novoTributo);
    return novoTributo;
  }

  async updateTributo(id: number, tributo: Partial<Tributo>): Promise<Tributo | undefined> {
    const existingTributo = this.tributos.get(id);
    if (!existingTributo) return undefined;

    const updatedTributo = {
      ...existingTributo,
      ...tributo,
      updatedAt: new Date(),
    };
    this.tributos.set(id, updatedTributo);
    return updatedTributo;
  }

  async deleteTributo(id: number): Promise<boolean> {
    return this.tributos.delete(id);
  }

  // Métodos para Precificações
  async getPrecificacao(id: number): Promise<Precificacao | undefined> {
    return this.precificacoes.get(id);
  }

  async getPrecificacoes(userId: number, tipo?: string): Promise<Precificacao[]> {
    return Array.from(this.precificacoes.values()).filter((precificacao) => {
      if (userId && precificacao.userId !== userId) return false;
      if (tipo && precificacao.tipo !== tipo) return false;
      return true;
    });
  }

  async createPrecificacao(precificacao: InsertPrecificacao): Promise<Precificacao> {
    const id = this.precificacaoIdCounter++;
    const now = new Date();
    const novaPrecificacao = { 
      ...precificacao, 
      id, 
      createdAt: now, 
      updatedAt: now,
    };
    this.precificacoes.set(id, novaPrecificacao);
    return novaPrecificacao;
  }

  async updatePrecificacao(id: number, precificacao: Partial<Precificacao>): Promise<Precificacao | undefined> {
    const existingPrecificacao = this.precificacoes.get(id);
    if (!existingPrecificacao) return undefined;

    const updatedPrecificacao = {
      ...existingPrecificacao,
      ...precificacao,
      updatedAt: new Date(),
    };
    this.precificacoes.set(id, updatedPrecificacao);
    return updatedPrecificacao;
  }

  async deletePrecificacao(id: number): Promise<boolean> {
    return this.precificacoes.delete(id);
  }
}

export const storage = new DatabaseStorage();
