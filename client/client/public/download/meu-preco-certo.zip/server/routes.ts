import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  loginSchema, insertUserSchema, 
  insertProdutoSchema, insertServicoSchema, insertItemAluguelSchema,
  insertFornecedorSchema, insertClienteSchema, insertMarketplaceSchema, insertCustoSchema, insertDespesaSchema,
  insertTaxaSchema, insertTributoSchema, insertPrecificacaoSchema, insertCategoriaSchema
} from "@shared/schema";
import {
  calcularPrecoProduto,
  calcularPrecoServico,
  calcularPrecoAluguel,
  calcularPrecoMarketplace
} from "./calculos";
import path from "path";
import express from "express";

export async function registerRoutes(app: Express): Promise<Server> {
  // Configuração para servir arquivos estáticos da pasta client/public
  const publicPath = path.resolve(process.cwd(), "client", "public");
  app.use(express.static(publicPath));
  // User registration endpoint
  app.post("/api/register", async (req, res) => {
    try {
      const parsedData = insertUserSchema.safeParse(req.body);
      
      if (!parsedData.success) {
        return res.status(400).json({ message: "Invalid user data" });
      }
      
      const existingUser = await storage.getUserByUsername(parsedData.data.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(parsedData.data);
      
      return res.status(201).json({ 
        id: user.id, 
        username: user.username,
        email: user.email 
      });
    } catch (error) {
      console.error("Registration error:", error);
      return res.status(500).json({ message: "Server error during registration" });
    }
  });

  // Verificar email endpoint
  app.post("/api/verify-email", async (req, res) => {
    try {
      const email = req.body.email;
      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        return res.status(404).json({ message: "Email não encontrado" });
      }
      
      return res.status(200).json({ message: "Email encontrado" });
    } catch (error) {
      console.error("Email verification error:", error);
      return res.status(500).json({ message: "Erro ao verificar email" });
    }
  });

  // Login endpoint
  app.post("/api/login", async (req, res) => {
    try {
      const parsedData = loginSchema.safeParse(req.body);
      
      if (!parsedData.success) {
        return res.status(400).json({ message: "Invalid login data" });
      }
      
      const user = await storage.getUserByUsername(parsedData.data.username);
      
      if (!user || user.password !== parsedData.data.password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      return res.status(200).json({ 
        id: user.id, 
        username: user.username,
        email: user.email 
      });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Server error during login" });
    }
  });

  // =========== PRODUTOS ROUTES ===========
  
  // Obter todos os produtos
  app.get("/api/produtos", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      const tipo = req.query.tipo as string;
      
      if (!userId) {
        return res.status(400).json({ message: "ID do usuário é obrigatório" });
      }
      
      const produtos = await storage.getProdutos(userId, tipo);
      return res.status(200).json(produtos);
    } catch (error) {
      console.error("Erro ao buscar produtos:", error);
      return res.status(500).json({ message: "Erro ao buscar produtos" });
    }
  });
  
  // Obter produto por ID
  app.get("/api/produtos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const produto = await storage.getProduto(id);
      
      if (!produto) {
        return res.status(404).json({ message: "Produto não encontrado" });
      }
      
      return res.status(200).json(produto);
    } catch (error) {
      console.error("Erro ao buscar produto:", error);
      return res.status(500).json({ message: "Erro ao buscar produto" });
    }
  });
  
  // Criar produto
  app.post("/api/produtos", async (req, res) => {
    try {
      const parsedData = insertProdutoSchema.safeParse(req.body);
      
      if (!parsedData.success) {
        return res.status(400).json({ 
          message: "Dados do produto inválidos", 
          errors: parsedData.error.errors 
        });
      }
      
      const produto = await storage.createProduto(parsedData.data);
      return res.status(201).json(produto);
    } catch (error) {
      console.error("Erro ao criar produto:", error);
      return res.status(500).json({ message: "Erro ao criar produto" });
    }
  });
  
  // Atualizar produto
  app.put("/api/produtos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingProduto = await storage.getProduto(id);
      
      if (!existingProduto) {
        return res.status(404).json({ message: "Produto não encontrado" });
      }
      
      const produto = await storage.updateProduto(id, req.body);
      return res.status(200).json(produto);
    } catch (error) {
      console.error("Erro ao atualizar produto:", error);
      return res.status(500).json({ message: "Erro ao atualizar produto" });
    }
  });
  
  // Deletar produto
  app.delete("/api/produtos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingProduto = await storage.getProduto(id);
      
      if (!existingProduto) {
        return res.status(404).json({ message: "Produto não encontrado" });
      }
      
      const deleted = await storage.deleteProduto(id);
      
      if (deleted) {
        return res.status(200).json({ message: "Produto excluído com sucesso" });
      } else {
        return res.status(500).json({ message: "Não foi possível excluir o produto" });
      }
    } catch (error) {
      console.error("Erro ao excluir produto:", error);
      return res.status(500).json({ message: "Erro ao excluir produto" });
    }
  });
  
  // =========== SERVIÇOS ROUTES ===========
  
  // Obter todos os serviços
  app.get("/api/servicos", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      
      if (!userId) {
        return res.status(400).json({ message: "ID do usuário é obrigatório" });
      }
      
      const servicos = await storage.getServicos(userId);
      return res.status(200).json(servicos);
    } catch (error) {
      console.error("Erro ao buscar serviços:", error);
      return res.status(500).json({ message: "Erro ao buscar serviços" });
    }
  });
  
  // Obter serviço por ID
  app.get("/api/servicos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const servico = await storage.getServico(id);
      
      if (!servico) {
        return res.status(404).json({ message: "Serviço não encontrado" });
      }
      
      return res.status(200).json(servico);
    } catch (error) {
      console.error("Erro ao buscar serviço:", error);
      return res.status(500).json({ message: "Erro ao buscar serviço" });
    }
  });
  
  // Criar serviço
  app.post("/api/servicos", async (req, res) => {
    try {
      const parsedData = insertServicoSchema.safeParse(req.body);
      
      if (!parsedData.success) {
        return res.status(400).json({ 
          message: "Dados do serviço inválidos", 
          errors: parsedData.error.errors 
        });
      }
      
      const servico = await storage.createServico(parsedData.data);
      return res.status(201).json(servico);
    } catch (error) {
      console.error("Erro ao criar serviço:", error);
      return res.status(500).json({ message: "Erro ao criar serviço" });
    }
  });
  
  // Atualizar serviço
  app.put("/api/servicos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingServico = await storage.getServico(id);
      
      if (!existingServico) {
        return res.status(404).json({ message: "Serviço não encontrado" });
      }
      
      const servico = await storage.updateServico(id, req.body);
      return res.status(200).json(servico);
    } catch (error) {
      console.error("Erro ao atualizar serviço:", error);
      return res.status(500).json({ message: "Erro ao atualizar serviço" });
    }
  });
  
  // Deletar serviço
  app.delete("/api/servicos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingServico = await storage.getServico(id);
      
      if (!existingServico) {
        return res.status(404).json({ message: "Serviço não encontrado" });
      }
      
      const deleted = await storage.deleteServico(id);
      
      if (deleted) {
        return res.status(200).json({ message: "Serviço excluído com sucesso" });
      } else {
        return res.status(500).json({ message: "Não foi possível excluir o serviço" });
      }
    } catch (error) {
      console.error("Erro ao excluir serviço:", error);
      return res.status(500).json({ message: "Erro ao excluir serviço" });
    }
  });
  
  // =========== ITENS PARA ALUGUEL ROUTES ===========
  
  // Obter todos os itens para aluguel
  app.get("/api/itens-aluguel", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      
      if (!userId) {
        return res.status(400).json({ message: "ID do usuário é obrigatório" });
      }
      
      const itens = await storage.getItensAluguel(userId);
      return res.status(200).json(itens);
    } catch (error) {
      console.error("Erro ao buscar itens para aluguel:", error);
      return res.status(500).json({ message: "Erro ao buscar itens para aluguel" });
    }
  });
  
  // Obter item para aluguel por ID
  app.get("/api/itens-aluguel/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getItemAluguel(id);
      
      if (!item) {
        return res.status(404).json({ message: "Item para aluguel não encontrado" });
      }
      
      return res.status(200).json(item);
    } catch (error) {
      console.error("Erro ao buscar item para aluguel:", error);
      return res.status(500).json({ message: "Erro ao buscar item para aluguel" });
    }
  });
  
  // Criar item para aluguel
  app.post("/api/itens-aluguel", async (req, res) => {
    try {
      const parsedData = insertItemAluguelSchema.safeParse(req.body);
      
      if (!parsedData.success) {
        return res.status(400).json({ 
          message: "Dados do item para aluguel inválidos", 
          errors: parsedData.error.errors 
        });
      }
      
      const item = await storage.createItemAluguel(parsedData.data);
      return res.status(201).json(item);
    } catch (error) {
      console.error("Erro ao criar item para aluguel:", error);
      return res.status(500).json({ message: "Erro ao criar item para aluguel" });
    }
  });
  
  // Atualizar item para aluguel
  app.put("/api/itens-aluguel/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingItem = await storage.getItemAluguel(id);
      
      if (!existingItem) {
        return res.status(404).json({ message: "Item para aluguel não encontrado" });
      }
      
      const item = await storage.updateItemAluguel(id, req.body);
      return res.status(200).json(item);
    } catch (error) {
      console.error("Erro ao atualizar item para aluguel:", error);
      return res.status(500).json({ message: "Erro ao atualizar item para aluguel" });
    }
  });
  
  // Deletar item para aluguel
  app.delete("/api/itens-aluguel/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingItem = await storage.getItemAluguel(id);
      
      if (!existingItem) {
        return res.status(404).json({ message: "Item para aluguel não encontrado" });
      }
      
      const deleted = await storage.deleteItemAluguel(id);
      
      if (deleted) {
        return res.status(200).json({ message: "Item para aluguel excluído com sucesso" });
      } else {
        return res.status(500).json({ message: "Não foi possível excluir o item para aluguel" });
      }
    } catch (error) {
      console.error("Erro ao excluir item para aluguel:", error);
      return res.status(500).json({ message: "Erro ao excluir item para aluguel" });
    }
  });
  
  // =========== FORNECEDORES ROUTES ===========
  
  // Obter todos os fornecedores
  app.get("/api/fornecedores", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      
      if (!userId) {
        return res.status(400).json({ message: "ID do usuário é obrigatório" });
      }
      
      const fornecedores = await storage.getFornecedores(userId);
      return res.status(200).json(fornecedores);
    } catch (error) {
      console.error("Erro ao buscar fornecedores:", error);
      return res.status(500).json({ message: "Erro ao buscar fornecedores" });
    }
  });
  
  // Obter fornecedor por ID
  app.get("/api/fornecedores/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const fornecedor = await storage.getFornecedor(id);
      
      if (!fornecedor) {
        return res.status(404).json({ message: "Fornecedor não encontrado" });
      }
      
      return res.status(200).json(fornecedor);
    } catch (error) {
      console.error("Erro ao buscar fornecedor:", error);
      return res.status(500).json({ message: "Erro ao buscar fornecedor" });
    }
  });
  
  // Criar fornecedor
  app.post("/api/fornecedores", async (req, res) => {
    try {
      const parsedData = insertFornecedorSchema.safeParse(req.body);
      
      if (!parsedData.success) {
        return res.status(400).json({ 
          message: "Dados do fornecedor inválidos", 
          errors: parsedData.error.errors 
        });
      }
      
      const fornecedor = await storage.createFornecedor(parsedData.data);
      return res.status(201).json(fornecedor);
    } catch (error) {
      console.error("Erro ao criar fornecedor:", error);
      return res.status(500).json({ message: "Erro ao criar fornecedor" });
    }
  });
  
  // Atualizar fornecedor
  app.put("/api/fornecedores/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingFornecedor = await storage.getFornecedor(id);
      
      if (!existingFornecedor) {
        return res.status(404).json({ message: "Fornecedor não encontrado" });
      }
      
      const fornecedor = await storage.updateFornecedor(id, req.body);
      return res.status(200).json(fornecedor);
    } catch (error) {
      console.error("Erro ao atualizar fornecedor:", error);
      return res.status(500).json({ message: "Erro ao atualizar fornecedor" });
    }
  });
  
  // Deletar fornecedor
  app.delete("/api/fornecedores/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingFornecedor = await storage.getFornecedor(id);
      
      if (!existingFornecedor) {
        return res.status(404).json({ message: "Fornecedor não encontrado" });
      }
      
      const deleted = await storage.deleteFornecedor(id);
      
      if (deleted) {
        return res.status(200).json({ message: "Fornecedor excluído com sucesso" });
      } else {
        return res.status(500).json({ message: "Não foi possível excluir o fornecedor" });
      }
    } catch (error) {
      console.error("Erro ao excluir fornecedor:", error);
      return res.status(500).json({ message: "Erro ao excluir fornecedor" });
    }
  });
  
  // =========== CLIENTES ROUTES ===========
  
  // Obter todos os clientes
  app.get("/api/clientes", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      
      if (!userId) {
        return res.status(400).json({ message: "ID do usuário é obrigatório" });
      }
      
      const clientes = await storage.getClientes(userId);
      return res.status(200).json(clientes);
    } catch (error) {
      console.error("Erro ao buscar clientes:", error);
      return res.status(500).json({ message: "Erro ao buscar clientes" });
    }
  });
  
  // Obter cliente por ID
  app.get("/api/clientes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const cliente = await storage.getCliente(id);
      
      if (!cliente) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }
      
      return res.status(200).json(cliente);
    } catch (error) {
      console.error("Erro ao buscar cliente:", error);
      return res.status(500).json({ message: "Erro ao buscar cliente" });
    }
  });
  
  // Criar cliente
  app.post("/api/clientes", async (req, res) => {
    try {
      const parsedData = insertClienteSchema.safeParse(req.body);
      
      if (!parsedData.success) {
        return res.status(400).json({ 
          message: "Dados do cliente inválidos", 
          errors: parsedData.error.errors 
        });
      }
      
      const cliente = await storage.createCliente(parsedData.data);
      return res.status(201).json(cliente);
    } catch (error) {
      console.error("Erro ao criar cliente:", error);
      return res.status(500).json({ message: "Erro ao criar cliente" });
    }
  });
  
  // Atualizar cliente
  app.put("/api/clientes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingCliente = await storage.getCliente(id);
      
      if (!existingCliente) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }
      
      const cliente = await storage.updateCliente(id, req.body);
      return res.status(200).json(cliente);
    } catch (error) {
      console.error("Erro ao atualizar cliente:", error);
      return res.status(500).json({ message: "Erro ao atualizar cliente" });
    }
  });
  
  // Deletar cliente
  app.delete("/api/clientes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingCliente = await storage.getCliente(id);
      
      if (!existingCliente) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }
      
      const deleted = await storage.deleteCliente(id);
      
      if (deleted) {
        return res.status(200).json({ message: "Cliente excluído com sucesso" });
      } else {
        return res.status(500).json({ message: "Não foi possível excluir o cliente" });
      }
    } catch (error) {
      console.error("Erro ao excluir cliente:", error);
      return res.status(500).json({ message: "Erro ao excluir cliente" });
    }
  });
  
  // =========== MARKETPLACES ROUTES ===========
  
  // Obter todos os marketplaces
  app.get("/api/marketplaces", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      
      if (!userId) {
        return res.status(400).json({ message: "ID do usuário é obrigatório" });
      }
      
      const marketplaces = await storage.getMarketplaces(userId);
      return res.status(200).json(marketplaces);
    } catch (error) {
      console.error("Erro ao buscar marketplaces:", error);
      return res.status(500).json({ message: "Erro ao buscar marketplaces" });
    }
  });
  
  // Obter marketplace por ID
  app.get("/api/marketplaces/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const marketplace = await storage.getMarketplace(id);
      
      if (!marketplace) {
        return res.status(404).json({ message: "Marketplace não encontrado" });
      }
      
      return res.status(200).json(marketplace);
    } catch (error) {
      console.error("Erro ao buscar marketplace:", error);
      return res.status(500).json({ message: "Erro ao buscar marketplace" });
    }
  });
  
  // Criar marketplace
  app.post("/api/marketplaces", async (req, res) => {
    try {
      const parsedData = insertMarketplaceSchema.safeParse(req.body);
      
      if (!parsedData.success) {
        return res.status(400).json({ 
          message: "Dados do marketplace inválidos", 
          errors: parsedData.error.errors 
        });
      }
      
      const marketplace = await storage.createMarketplace(parsedData.data);
      return res.status(201).json(marketplace);
    } catch (error) {
      console.error("Erro ao criar marketplace:", error);
      return res.status(500).json({ message: "Erro ao criar marketplace" });
    }
  });
  
  // =========== CATEGORIAS ROUTES ===========
  
  // Obter todas as categorias
  app.get("/api/categorias", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      const tipo = req.query.tipo as string;
      
      if (!userId) {
        return res.status(400).json({ message: "ID do usuário é obrigatório" });
      }
      
      const categorias = await storage.getCategorias(userId, tipo);
      return res.status(200).json(categorias);
    } catch (error) {
      console.error("Erro ao buscar categorias:", error);
      return res.status(500).json({ message: "Erro ao buscar categorias" });
    }
  });
  
  // Obter categoria por ID
  app.get("/api/categorias/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const categoria = await storage.getCategoria(id);
      
      if (!categoria) {
        return res.status(404).json({ message: "Categoria não encontrada" });
      }
      
      return res.status(200).json(categoria);
    } catch (error) {
      console.error("Erro ao buscar categoria:", error);
      return res.status(500).json({ message: "Erro ao buscar categoria" });
    }
  });
  
  // Criar categoria
  app.post("/api/categorias", async (req, res) => {
    try {
      const parsedData = insertCategoriaSchema.safeParse(req.body);
      
      if (!parsedData.success) {
        return res.status(400).json({ 
          message: "Dados da categoria inválidos", 
          errors: parsedData.error.errors 
        });
      }
      
      const categoria = await storage.createCategoria(parsedData.data);
      return res.status(201).json(categoria);
    } catch (error) {
      console.error("Erro ao criar categoria:", error);
      return res.status(500).json({ message: "Erro ao criar categoria" });
    }
  });
  
  // Atualizar categoria
  app.put("/api/categorias/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingCategoria = await storage.getCategoria(id);
      
      if (!existingCategoria) {
        return res.status(404).json({ message: "Categoria não encontrada" });
      }
      
      const categoria = await storage.updateCategoria(id, req.body);
      return res.status(200).json(categoria);
    } catch (error) {
      console.error("Erro ao atualizar categoria:", error);
      return res.status(500).json({ message: "Erro ao atualizar categoria" });
    }
  });
  
  // Deletar categoria
  app.delete("/api/categorias/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingCategoria = await storage.getCategoria(id);
      
      if (!existingCategoria) {
        return res.status(404).json({ message: "Categoria não encontrada" });
      }
      
      const deleted = await storage.deleteCategoria(id);
      
      if (deleted) {
        return res.status(200).json({ message: "Categoria excluída com sucesso" });
      } else {
        return res.status(500).json({ message: "Não foi possível excluir a categoria" });
      }
    } catch (error) {
      console.error("Erro ao excluir categoria:", error);
      return res.status(500).json({ message: "Erro ao excluir categoria" });
    }
  });
  
  // =========== CÁLCULOS DE PRECIFICAÇÃO ===========
  
  // Calcular preço de produto
  app.post("/api/calculos/produto", async (req, res) => {
    try {
      const {
        valorCusto,
        frete,
        lucroPercentual,
        formaPagamento,
        parcelas,
        custos,
        taxas
      } = req.body;
      
      // Validação básica de entrada
      if (valorCusto === undefined || lucroPercentual === undefined || !formaPagamento) {
        return res.status(400).json({ 
          message: "Parâmetros insuficientes para cálculo" 
        });
      }
      
      // Converte valores para números
      const params = {
        valorCusto: Number(valorCusto),
        frete: frete ? Number(frete) : undefined,
        lucroPercentual: Number(lucroPercentual),
        formaPagamento,
        parcelas: parcelas ? Number(parcelas) : undefined,
        custos: custos ? custos.map(Number) : undefined,
        taxas
      };
      
      const resultado = calcularPrecoProduto(params);
      return res.status(200).json(resultado);
    } catch (error) {
      console.error("Erro ao calcular preço de produto:", error);
      return res.status(500).json({ message: "Erro ao calcular preço de produto" });
    }
  });
  
  // Calcular preço de serviço
  app.post("/api/calculos/servico", async (req, res) => {
    try {
      const {
        valorCusto,
        deslocamento,
        valorKm,
        lucroPercentual,
        formaPagamento,
        parcelas,
        custos,
        taxas
      } = req.body;
      
      // Validação básica de entrada
      if (valorCusto === undefined || lucroPercentual === undefined || !formaPagamento) {
        return res.status(400).json({ 
          message: "Parâmetros insuficientes para cálculo" 
        });
      }
      
      // Converte valores para números
      const params = {
        valorCusto: Number(valorCusto),
        deslocamento: deslocamento ? Number(deslocamento) : undefined,
        valorKm: valorKm ? Number(valorKm) : undefined,
        lucroPercentual: Number(lucroPercentual),
        formaPagamento,
        parcelas: parcelas ? Number(parcelas) : undefined,
        custos: custos ? custos.map(Number) : undefined,
        taxas
      };
      
      const resultado = calcularPrecoServico(params);
      return res.status(200).json(resultado);
    } catch (error) {
      console.error("Erro ao calcular preço de serviço:", error);
      return res.status(500).json({ message: "Erro ao calcular preço de serviço" });
    }
  });
  
  // Calcular preço de aluguel
  app.post("/api/calculos/aluguel", async (req, res) => {
    try {
      const {
        valorEquipamento,
        frete,
        retornoInvestimentoMeses,
        tempoContratoMeses,
        lucroMensalPercentual,
        deslocamento,
        valorKm,
        formaPagamento,
        parcelas,
        custos,
        taxas
      } = req.body;
      
      // Validação básica de entrada
      if (valorEquipamento === undefined || 
          retornoInvestimentoMeses === undefined || 
          tempoContratoMeses === undefined || 
          lucroMensalPercentual === undefined || 
          !formaPagamento) {
        return res.status(400).json({ 
          message: "Parâmetros insuficientes para cálculo" 
        });
      }
      
      // Converte valores para números
      const params = {
        valorEquipamento: Number(valorEquipamento),
        frete: frete ? Number(frete) : undefined,
        retornoInvestimentoMeses: Number(retornoInvestimentoMeses),
        tempoContratoMeses: Number(tempoContratoMeses),
        lucroMensalPercentual: Number(lucroMensalPercentual),
        deslocamento: deslocamento ? Number(deslocamento) : undefined,
        valorKm: valorKm ? Number(valorKm) : undefined,
        formaPagamento,
        parcelas: parcelas ? Number(parcelas) : undefined,
        custos: custos ? custos.map(Number) : undefined,
        taxas
      };
      
      const resultado = calcularPrecoAluguel(params);
      return res.status(200).json(resultado);
    } catch (error) {
      console.error("Erro ao calcular preço de aluguel:", error);
      return res.status(500).json({ message: "Erro ao calcular preço de aluguel" });
    }
  });
  
  // Calcular preço para marketplace
  app.post("/api/calculos/marketplace", async (req, res) => {
    try {
      const {
        valorCusto,
        frete,
        lucroPercentual,
        taxaMarketplace,
        formaPagamento,
        parcelas,
        custos,
        taxas
      } = req.body;
      
      // Validação básica de entrada
      if (valorCusto === undefined || 
          lucroPercentual === undefined || 
          taxaMarketplace === undefined || 
          !formaPagamento) {
        return res.status(400).json({ 
          message: "Parâmetros insuficientes para cálculo" 
        });
      }
      
      // Converte valores para números
      const params = {
        valorCusto: Number(valorCusto),
        frete: frete ? Number(frete) : undefined,
        lucroPercentual: Number(lucroPercentual),
        taxaMarketplace: Number(taxaMarketplace),
        formaPagamento,
        parcelas: parcelas ? Number(parcelas) : undefined,
        custos: custos ? custos.map(Number) : undefined,
        taxas
      };
      
      const resultado = calcularPrecoMarketplace(params);
      return res.status(200).json(resultado);
    } catch (error) {
      console.error("Erro ao calcular preço para marketplace:", error);
      return res.status(500).json({ message: "Erro ao calcular preço para marketplace" });
    }
  });
  
  const httpServer = createServer(app);

  return httpServer;
}
