import { pgTable, text, serial, integer, boolean, numeric, timestamp, date, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
});

export const insertUserSchema = createInsertSchema(users)
  .pick({
    username: true,
    password: true,
    email: true,
  })
  .extend({
    password: z.string()
      .min(8, "Senha deve ter pelo menos 8 caracteres")
      .regex(/[A-Z]/, "Senha deve conter pelo menos uma letra maiúscula")
      .regex(/[a-z]/, "Senha deve conter pelo menos uma letra minúscula")
      .regex(/[0-9]/, "Senha deve conter pelo menos um número")
      .regex(/[^A-Za-z0-9]/, "Senha deve conter pelo menos um caractere especial")
  });

export const loginSchema = z.object({
  username: z.string().min(1, { message: "Username is required" }),
  password: z.string().min(1, { message: "Password is required" }),
});

// Enums
export const produtoTipoEnum = pgEnum('produto_tipo', ['novo', 'usado']);
export const custoTipoEnum = pgEnum('custo_tipo', ['novo', 'usado', 'aluguel', 'servico', 'marketplace']);
export const despesaTipoEnum = pgEnum('despesa_tipo', ['fixa', 'variavel']);
export const formaPagamentoEnum = pgEnum('forma_pagamento', ['a_vista', 'cartao_credito', 'boleto', 'pix', 'transferencia']);
export const categoriaTipoEnum = pgEnum('categoria_tipo', ['produto', 'servico', 'despesa', 'custo']);

// Produtos
export const produtos = pgTable("produtos", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  codigo: text("codigo"),
  tipo: produtoTipoEnum("tipo").notNull(),
  valorCusto: numeric("valor_custo").notNull(),
  frete: numeric("frete"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Serviços
export const servicos = pgTable("servicos", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  valorCusto: numeric("valor_custo").notNull(),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Itens para Aluguel
export const itensAluguel = pgTable("itens_aluguel", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  valorEquipamento: numeric("valor_equipamento").notNull(),
  frete: numeric("frete"),
  retornoInvestimentoMeses: integer("retorno_investimento_meses").notNull(),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Fornecedores
export const fornecedores = pgTable("fornecedores", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  cnpj: text("cnpj"),
  telefone: text("telefone"),
  email: text("email"),
  contato: text("contato"),
  endereco: text("endereco"),
  cidade: text("cidade"),
  estado: text("estado"),
  observacoes: text("observacoes"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Clientes
export const clientes = pgTable("clientes", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  cpfCnpj: text("cpf_cnpj"),
  telefone: text("telefone"),
  celular: text("celular"),
  email: text("email"),
  endereco: text("endereco"),
  numero: text("numero"),
  complemento: text("complemento"),
  bairro: text("bairro"),
  cidade: text("cidade"),
  estado: text("estado"),
  cep: text("cep"),
  dataNascimento: date("data_nascimento"),
  observacoes: text("observacoes"),
  ativo: boolean("ativo").default(true),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Marketplaces
export const marketplaces = pgTable("marketplaces", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  taxa: numeric("taxa").notNull(),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Custos
export const custos = pgTable("custos", {
  id: serial("id").primaryKey(),
  descricao: text("descricao").notNull(),
  valor: numeric("valor").notNull(),
  tipo: custoTipoEnum("tipo").notNull(),
  observacoes: text("observacoes"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Despesas
export const despesas = pgTable("despesas", {
  id: serial("id").primaryKey(),
  descricao: text("descricao").notNull(),
  valor: numeric("valor").notNull(),
  tipo: despesaTipoEnum("tipo").notNull(),
  categoria: custoTipoEnum("categoria").notNull(),
  ocorrenciaMeses: integer("ocorrencia_meses"),
  observacoes: text("observacoes"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Taxas
export const taxas = pgTable("taxas", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  valor: numeric("valor").notNull(),
  tipo: text("tipo").notNull(), // 'bancaria', 'maquininha', 'operadora'
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Tributos
export const tributos = pgTable("tributos", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  sigla: text("sigla"),
  porcentagem: numeric("porcentagem").notNull(),
  descricao: text("descricao"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Categorias
export const categorias = pgTable("categorias", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  tipo: categoriaTipoEnum("tipo").notNull(),
  ordem: integer("ordem"),
  ativa: boolean("ativa").default(true),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Precificações
export const precificacoes = pgTable("precificacoes", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  tipo: custoTipoEnum("tipo").notNull(),
  referenceId: integer("reference_id"), // Id do produto, serviço, item para aluguel
  valorCusto: numeric("valor_custo").notNull(),
  frete: numeric("frete"),
  lucro: numeric("lucro").notNull(),
  formaPagamento: formaPagamentoEnum("forma_pagamento").notNull(),
  parcelas: integer("parcelas"),
  deslocamento: numeric("deslocamento"),
  valorVenda: numeric("valor_venda").notNull(),
  lucroBruto: numeric("lucro_bruto").notNull(),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// INSERT schemas
export const insertProdutoSchema = createInsertSchema(produtos).omit({ id: true, createdAt: true, updatedAt: true });
export const insertServicoSchema = createInsertSchema(servicos).omit({ id: true, createdAt: true, updatedAt: true });
export const insertItemAluguelSchema = createInsertSchema(itensAluguel).omit({ id: true, createdAt: true, updatedAt: true });
export const insertFornecedorSchema = createInsertSchema(fornecedores).omit({ id: true, createdAt: true, updatedAt: true });
export const insertClienteSchema = createInsertSchema(clientes).omit({ id: true, createdAt: true, updatedAt: true });
export const insertMarketplaceSchema = createInsertSchema(marketplaces).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCustoSchema = createInsertSchema(custos).omit({ id: true, createdAt: true, updatedAt: true });
export const insertDespesaSchema = createInsertSchema(despesas).omit({ id: true, createdAt: true, updatedAt: true });
export const insertTaxaSchema = createInsertSchema(taxas).omit({ id: true, createdAt: true, updatedAt: true });
export const insertTributoSchema = createInsertSchema(tributos).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCategoriaSchema = createInsertSchema(categorias).omit({ id: true, createdAt: true, updatedAt: true });
export const insertPrecificacaoSchema = createInsertSchema(precificacoes).omit({ id: true, createdAt: true, updatedAt: true });

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type LoginCredentials = z.infer<typeof loginSchema>;

export type InsertProduto = z.infer<typeof insertProdutoSchema>;
export type Produto = typeof produtos.$inferSelect;

export type InsertServico = z.infer<typeof insertServicoSchema>;
export type Servico = typeof servicos.$inferSelect;

export type InsertItemAluguel = z.infer<typeof insertItemAluguelSchema>;
export type ItemAluguel = typeof itensAluguel.$inferSelect;

export type InsertFornecedor = z.infer<typeof insertFornecedorSchema>;
export type Fornecedor = typeof fornecedores.$inferSelect;

export type InsertMarketplace = z.infer<typeof insertMarketplaceSchema>;
export type Marketplace = typeof marketplaces.$inferSelect;

export type InsertCusto = z.infer<typeof insertCustoSchema>;
export type Custo = typeof custos.$inferSelect;

export type InsertDespesa = z.infer<typeof insertDespesaSchema>;
export type Despesa = typeof despesas.$inferSelect;

export type InsertTaxa = z.infer<typeof insertTaxaSchema>;
export type Taxa = typeof taxas.$inferSelect;

export type InsertTributo = z.infer<typeof insertTributoSchema>;
export type Tributo = typeof tributos.$inferSelect;

export type InsertPrecificacao = z.infer<typeof insertPrecificacaoSchema>;
export type Precificacao = typeof precificacoes.$inferSelect;

export type InsertCategoria = z.infer<typeof insertCategoriaSchema>;
export type Categoria = typeof categorias.$inferSelect;

export type InsertCliente = z.infer<typeof insertClienteSchema>;
export type Cliente = typeof clientes.$inferSelect;
