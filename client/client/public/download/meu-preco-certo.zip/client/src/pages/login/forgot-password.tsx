import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Building, ChevronRight, ArrowLeft, Loader2, Check, ShieldCheck, Lock, Mail } from "lucide-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import LogoDesktop from "@/assets/images/logo/Negativo.png";
import LogoMobile from "@/assets/images/logo/principal.png";

// Schema de validação para recuperação de senha
const forgotPasswordSchema = z.object({
  email: z.string().email({ message: "Por favor, insira um endereço de e-mail válido" }),
});

type ForgotPasswordFormValues = z.infer<typeof forgotPasswordSchema>;

export default function ForgotPasswordPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [emailEnviado, setEmailEnviado] = useState(false);

  const form = useForm<ForgotPasswordFormValues>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      email: "",
    }
  });

  async function onSubmit(data: ForgotPasswordFormValues) {
    setIsLoading(true);

    try {
      // Em uma aplicação real, chamaríamos a API para enviar o e-mail de recuperação
      await new Promise(resolve => setTimeout(resolve, 1500));

      setEmailEnviado(true);

      toast({
        title: "E-mail enviado",
        description: "Instruções para redefinição de senha foram enviadas para o seu e-mail.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao processar solicitação",
        description: "Não foi possível enviar o e-mail. Por favor, tente novamente.",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-white flex flex-col md:flex-row">
      {/* Seção de apresentação - à esquerda */}
      <div className="hidden md:flex md:w-1/2 lg:w-3/5 xl:w-2/3 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-700 via-purple-600 to-blue-600"></div>
        <div className="absolute inset-0" style={{ 
          backgroundImage: "radial-gradient(circle at 25% 25%, rgba(255, 255, 255, 0.2) 0%, transparent 50%), radial-gradient(circle at 75% 75%, rgba(255, 255, 255, 0.15) 0%, transparent 45%)" 
        }}></div>
        <div className="absolute inset-0 opacity-20" style={{ 
          backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" 
        }}></div>

        <div className="relative w-full h-full z-10">
          <div className="w-full h-full flex flex-col justify-center items-center p-4 md:p-6 lg:p-8">
            {/* Logo e marca - versão desktop */}
            <div className="flex flex-col items-center mb-6">
              <img src={LogoDesktop} alt="Meu Preço Certo" className="h-20 mb-4" />
            </div>

            {/* Conteúdo central destacado */}
            <div className="max-w-xl">
              <div className="flex items-center justify-center mb-3">
                <div className="px-3 py-1 rounded-full bg-white/20 text-white text-sm font-medium backdrop-blur-sm">
                  Recuperação segura de acesso
                </div>
              </div>

              <h2 className="text-2xl md:text-3xl font-bold text-center text-white mb-6">
                Recupere o acesso a sua
                <span className="bg-gradient-to-r from-yellow-300 to-amber-500 bg-clip-text text-transparent">
                  {" "}conta 
                </span>
              </h2>

              {/* Simulação visual do processo de recuperação */}
              <div className="w-full bg-white rounded-xl shadow-xl p-8 mb-12">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-xl font-bold">Processo de recuperação</h3>
                  <div className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded-full font-medium">Seguro</div>
                </div>

                {/* Etapas do processo de recuperação */}
                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 bg-primary text-white h-8 w-8 rounded-full flex items-center justify-center mr-4">
                      1
                    </div>
                    <div>
                      <div className="font-medium mb-1">Solicitação de redefinição</div>
                      <div className="text-sm text-gray-600">Informe o e-mail cadastrado para receber o link de recuperação.</div>
                      <div className="mt-2 flex items-center">
                        <Mail className="h-4 w-4 text-blue-500 mr-1" />
                        <div className="text-xs text-blue-600">E-mail enviado para o endereço cadastrado</div>
                      </div>
                    </div>
                  </div>

                  <div className="w-px h-4 bg-gray-200 ml-4"></div>

                  <div className="flex items-start opacity-75">
                    <div className="flex-shrink-0 bg-gray-300 text-white h-8 w-8 rounded-full flex items-center justify-center mr-4">
                      2
                    </div>
                    <div>
                      <div className="font-medium mb-1">Acesso ao link</div>
                      <div className="text-sm text-gray-600">Clique no link enviado para seu e-mail para iniciar a redefinição.</div>
                      <div className="h-1 w-full bg-gray-100 rounded-full mt-2">
                        <div className="h-1 w-0 bg-blue-500 rounded-full"></div>
                      </div>
                    </div>
                  </div>

                  <div className="w-px h-4 bg-gray-200 ml-4"></div>

                  <div className="flex items-start opacity-50">
                    <div className="flex-shrink-0 bg-gray-300 text-white h-8 w-8 rounded-full flex items-center justify-center mr-4">
                      3
                    </div>
                    <div>
                      <div className="font-medium mb-1">Nova senha</div>
                      <div className="text-sm text-gray-600">Defina sua nova senha seguindo os critérios de segurança.</div>
                      <div className="mt-2 flex space-x-2">
                        <div className="h-1 w-12 bg-gray-200 rounded-full"></div>
                        <div className="h-1 w-12 bg-gray-200 rounded-full"></div>
                        <div className="h-1 w-12 bg-gray-200 rounded-full"></div>
                        <div className="h-1 w-12 bg-gray-200 rounded-full"></div>
                      </div>
                    </div>
                  </div>

                  <div className="w-px h-4 bg-gray-200 ml-4"></div>

                  <div className="flex items-start opacity-25">
                    <div className="flex-shrink-0 bg-gray-300 text-white h-8 w-8 rounded-full flex items-center justify-center mr-4">
                      4
                    </div>
                    <div>
                      <div className="font-medium mb-1">Acesso recuperado</div>
                      <div className="text-sm text-gray-600">Você poderá acessar sua conta com a nova senha definida.</div>
                      <div className="mt-2 flex items-center">
                        <Lock className="h-4 w-4 text-gray-400 mr-1" />
                        <div className="text-xs text-gray-400">Acesso restaurado</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Seção de formulário - à direita */}
      <div className="w-full md:w-1/2 lg:w-2/5 xl:w-1/3 p-4 md:p-6 lg:p-8 flex flex-col justify-center bg-white">
        <div className="mx-auto w-full max-w-md">
          {/* Logo e cabeçalho (visível apenas em mobile) */}
          <div className="md:hidden text-center mb-6 mt-8">
            <img src={LogoMobile} alt="Meu Preço Certo" className="h-24 mx-auto mb-6" />
          </div>

          {/* Botão voltar (usando exatamente a mesma altura que na página de login) */}
          <div className="h-[42px] flex items-start">
            <Button
              variant="ghost"
              className="px-0 text-gray-600 hover:text-gray-900 hover:bg-transparent"
              onClick={() => setLocation("/acessar")}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar para o login
            </Button>
          </div>

          {/* Título e subtítulo */}
          <div className="mb-8">
            <h2 className="text-3xl font-extrabold mb-3 text-gray-900">Esqueceu sua senha?</h2>
            <div className="text-gray-600">
              <span style={{whiteSpace: 'nowrap'}}>Recupere o acesso a sua conta em instantes.</span>
            </div>
          </div>

          {emailEnviado ? (
            <div className="text-center">
              <div className="mx-auto w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
                <Check className="h-10 w-10 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-3">E-mail enviado!</h3>
              <p className="text-gray-600 mb-8">
                Verifique sua caixa de entrada e siga as instruções que enviamos para {form.getValues().email}
              </p>
              <Button
                variant="outline"
                className="w-full h-12 rounded-lg"
                onClick={() => setLocation("/acessar")}
              >
                Voltar para o login
              </Button>
            </div>
          ) : (
            /* Formulário de recuperação de senha */
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700 font-medium">E-mail</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          className={`h-12 rounded-lg border-gray-300 focus:border-primary focus:ring focus:ring-primary/20 ${
                            form.formState.errors.email ? 'border-red-500 ring ring-red-200' : ''
                          }`}
                          placeholder="seu@email.com"
                          autoComplete="email"
                          onBlur={(e) => {
                            field.onBlur();
                            // Validação adicional pode ser feita aqui se necessário
                          }}
                        />
                      </FormControl>
                      <FormMessage className="text-xs font-medium" />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  className="w-full h-12 bg-primary hover:bg-primary/90 text-white font-semibold rounded-lg flex items-center justify-center group"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span className="flex items-center">
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Processando...
                    </span>
                  ) : (
                    <span className="flex items-center">
                      Enviar instruções
                      <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </span>
                  )}
                </Button>
              </form>
            </Form>
          )}

          {/* Rodapé */}
          <div className="mt-12 text-center text-gray-500 text-xs">
            <p>© {new Date().getFullYear()} Meu Preço Certo. Todos os direitos reservados.</p>
            <div className="mt-2">
              <a href="#" className="mx-2 hover:text-gray-700 transition-colors">Política de Privacidade</a>
              <a href="#" className="mx-2 hover:text-gray-700 transition-colors">Termos de Serviço</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}