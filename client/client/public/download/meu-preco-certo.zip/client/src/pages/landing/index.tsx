import React, { useState, useEffect } from "react";
import { Check, ArrowRight, Menu, HelpCircle, Clipboard, Info, Calculator, DollarSign, Percent, CreditCard, Truck, Tag, ArrowDownRight, AlertTriangle, Shield, FileText, X } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";

// Importar as imagens do projeto
import positiveLogoPath from "@/assets/images/Principal.png";
import negativeLogoPath from "@/assets/images/Negativo.png";
import dashboardIllustration from "@/assets/images/dashboard-illustration-1.png";
import SplashScreen from "../splash";

// Importar estilos customizados
import "./style.css";

// Componente de navegação para a landing page
const LandingNav: React.FC<{scrolled: boolean}> = ({ scrolled }) => {
  const [, navigate] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled ? 'bg-white shadow-md' : 'bg-black/20 backdrop-blur-sm'
    } py-4`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex-shrink-0">
            <img 
              src={scrolled ? positiveLogoPath : negativeLogoPath} 
              alt="Meu Preço Certo" 
              className="h-10 w-auto transition-all duration-300"
            />
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center">
            <div className="flex space-x-5 items-center">
              <a 
                href="#" 
                className={`text-sm font-medium transition-colors ${
                  scrolled ? 'text-gray-700 hover:text-purple-700' : 'text-white hover:text-purple-200'
                }`}
              >
                Home
              </a>
              <a 
                href="#" 
                className={`text-sm font-medium transition-colors ${
                  scrolled ? 'text-gray-700 hover:text-purple-700' : 'text-white hover:text-purple-200'
                }`}
              >
                Planos
              </a>
              <a 
                href="#" 
                className={`text-sm font-medium transition-colors ${
                  scrolled ? 'text-gray-700 hover:text-purple-700' : 'text-white hover:text-purple-200'
                }`}
              >
                Depoimentos
              </a>
              <a 
                href="#" 
                className={`text-sm font-medium transition-colors ${
                  scrolled ? 'text-gray-700 hover:text-purple-700' : 'text-white hover:text-purple-200'
                }`}
              >
                Suporte
              </a>
              <div className="relative group">
                <a 
                  href="#" 
                  className={`text-sm font-medium transition-colors flex items-center ${
                    scrolled ? 'text-gray-700 hover:text-purple-700' : 'text-white hover:text-purple-200'
                  }`}
                >
                  Mais Informações
                  <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </a>
              </div>
            </div>
            <div className="flex ml-6">
              <Button 
                variant="secondary" 
                size="sm" 
                className="bg-purple-200 hover:bg-purple-300 text-purple-900 rounded-md"
                onClick={() => navigate("/cadastre-se")}
              >
                Cadastre-se
              </Button>
              <Button 
                className="bg-cyan-400 hover:bg-cyan-500 text-white rounded-md ml-2"
                size="sm"
                onClick={() => navigate("/acessar")}
              >
                Entrar
              </Button>
            </div>
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-500 focus:outline-none"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu className={`h-6 w-6 ${scrolled ? 'text-gray-700' : 'text-white'}`} />
          </button>
        </div>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 bg-white rounded-lg shadow-lg py-4 px-2">
            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg">
              Home
            </a>
            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg">
              Planos
            </a>
            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg">
              Depoimentos
            </a>
            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg">
              Suporte
            </a>
            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg">
              Mais Informações
            </a>
            <div className="mt-3 space-y-2 pt-3 border-t border-gray-200">
              <Button 
                variant="secondary" 
                size="sm" 
                className="w-full justify-center bg-purple-200 text-purple-900"
                onClick={() => navigate("/cadastre-se")}
              >
                Cadastre-se
              </Button>
              <Button 
                className="w-full justify-center bg-cyan-400 text-white"
                size="sm"
                onClick={() => navigate("/acessar")}
              >
                Entrar
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default function LandingPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [scrolled, setScrolled] = useState(false);
  const [imagesLoaded, setImagesLoaded] = useState(false);
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    custoProduto: '',
    frete: '',
    valorVenda: '',
    formaPagamento: 'Dinheiro',
    quantidadeParcelas: '1X',
    regimeTributario: 'MEI',
    lucroPercentual: '30',
    tipoLucro: 'BRUTO'
  });
  const [calculoResultado, setCalculoResultado] = useState<{
    valorFinal: number;
    lucro: number;
    margemLucro: number;
    valorParcela?: number;
  } | null>(null);
  const [concordaTermos, setConcordaTermos] = useState(false);
  const [showTermosModal, setShowTermosModal] = useState(false);
  const [showPrivacidadeModal, setShowPrivacidadeModal] = useState(false);
  const [camposValidados, setCamposValidados] = useState({
    nome: true,
    email: true,
    telefone: true
  });
  
  // Função para validar formato de email
  const isValidEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email.trim());
  };

  // Função para validar formato de telefone
  const isValidPhone = (phone: string): boolean => {
    // Verifica se tem formato (XX) XXXXX-XXXX ou pelo menos (XX) XXXX-XXXX
    const phoneRegex = /^\(\d{2}\) \d{4,5}\-\d{4}$/;
    return phoneRegex.test(phone.trim());
  };

  // Função para verificar se formulário está válido para cálculo
  const isFormValid = () => {
    return (
      formData.nome.trim() !== "" && 
      isValidEmail(formData.email) && 
      isValidPhone(formData.telefone) && 
      concordaTermos
    );
  };

  // Pré-carregar imagens
  useEffect(() => {
    const preloadImages = async () => {
      const imagePromises = [
        new Promise((resolve) => {
          const img = new Image();
          img.src = dashboardIllustration;
          img.onload = resolve;
        }),
        new Promise((resolve) => {
          const img = new Image();
          img.src = positiveLogoPath;
          img.onload = resolve;
        }),
        new Promise((resolve) => {
          const img = new Image();
          img.src = negativeLogoPath;
          img.onload = resolve;
        })
      ];

      // Aguardar todas as imagens carregarem
      await Promise.all(imagePromises);
      setImagesLoaded(true);
    };

    preloadImages();
  }, []);
  
  // Efeito para detectar rolagem da página
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 50;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [scrolled]);

  // Função para formatar números de telefone
  const formatPhoneNumber = (value: string): string => {
    // Remove todos os caracteres não numéricos
    const numbersOnly = value.replace(/\D/g, '');
    
    // Aplica a formatação de acordo com a quantidade de dígitos
    if (numbersOnly.length <= 2) {
      return numbersOnly;
    } else if (numbersOnly.length <= 6) {
      return `(${numbersOnly.slice(0, 2)}) ${numbersOnly.slice(2)}`;
    } else if (numbersOnly.length <= 10) {
      return `(${numbersOnly.slice(0, 2)}) ${numbersOnly.slice(2, 6)}-${numbersOnly.slice(6)}`;
    } else {
      return `(${numbersOnly.slice(0, 2)}) ${numbersOnly.slice(2, 7)}-${numbersOnly.slice(7, 11)}`;
    }
  };
  
  // Função para formatar valores monetários
  const formatCurrency = (value: string): string => {
    // Remove todos os caracteres não numéricos e pontos
    let numbersOnly = value.replace(/[^\d]/g, '');
    
    // Converte para número e formata como moeda
    const amount = parseFloat(numbersOnly) / 100;
    
    // Se for um número válido, retorna formatado
    if (!isNaN(amount)) {
      return amount.toLocaleString('pt-BR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
    }
    
    return numbersOnly ? formatCurrency(numbersOnly) : "";
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    // Aplica máscara de acordo com o campo
    let formattedValue = value;
    
    if (name === 'telefone') {
      formattedValue = formatPhoneNumber(value);
    } else if (['custoProduto', 'frete', 'valorVenda'].includes(name)) {
      formattedValue = formatCurrency(value);
    }
    
    setFormData({
      ...formData,
      [name]: formattedValue
    });
  };
  
  // Função para validar os campos quando o usuário sai do input
  const handleInputBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    if (name === 'nome') {
      setCamposValidados(prev => ({
        ...prev,
        nome: value.trim() !== ''
      }));
    } else if (name === 'email') {
      setCamposValidados(prev => ({
        ...prev,
        email: value.trim() === '' || isValidEmail(value)
      }));
    } else if (name === 'telefone') {
      setCamposValidados(prev => ({
        ...prev,
        telefone: value.trim() === '' || isValidPhone(value)
      }));
    }
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };

  // Função para mostrar informações sobre cada campo via toast
  const mostrarAjuda = (campo: string) => {
    const mensagens: Record<string, { titulo: string; descricao: string }> = {
      custoProduto: {
        titulo: "Custo do Produto",
        descricao: "Informe quanto você paga pelo produto, incluindo impostos na compra."
      },
      frete: {
        titulo: "Frete",
        descricao: "Valor do frete para receber o produto do fornecedor ou enviar ao cliente."
      },
      valorVenda: {
        titulo: "Valor de Venda",
        descricao: "O preço que você cobra pelo produto ao cliente final."
      },
      formaPagamento: {
        titulo: "Forma de Pagamento",
        descricao: "Cada forma de pagamento tem taxas diferentes que impactam seu lucro final."
      },
      quantidadeParcelas: {
        titulo: "Quantidade de Parcelas",
        descricao: "Quanto mais parcelas, maior a taxa cobrada pelas operadoras de cartão."
      },
      regimeTributario: {
        titulo: "Regime Tributário",
        descricao: "Seu regime tributário afeta os impostos a pagar sobre a venda."
      }
    };

    const info = mensagens[campo];
    if (info) {
      toast({
        title: info.titulo,
        description: info.descricao,
        variant: "default",
        duration: 5000,
      });
    }
  };

  // Função para copiar valor para a área de transferência
  const copiarValor = (valor: string, tipo: string) => {
    navigator.clipboard.writeText(valor).then(() => {
      toast({
        title: "Valor copiado!",
        description: `${tipo} copiado para a área de transferência.`,
        variant: "default",
        duration: 3000,
      });
    }).catch(() => {
      toast({
        title: "Erro ao copiar",
        description: "Não foi possível copiar o valor. Tente novamente.",
        variant: "destructive",
        duration: 3000,
      });
    });
  };

  const handleCalcular = (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Converter strings formatadas para números
      const custoProduto = parseFloat(formData.custoProduto.replace(/\./g, '').replace(',', '.')) || 0;
      const frete = parseFloat(formData.frete.replace(/\./g, '').replace(',', '.')) || 0;
      const valorVenda = parseFloat(formData.valorVenda.replace(/\./g, '').replace(',', '.')) || 0;
      
      // Validar entradas
      if (custoProduto <= 0 || valorVenda <= 0) {
        toast({
          title: "Valores inválidos",
          description: "Os valores de custo e venda devem ser maiores que zero.",
          variant: "destructive",
          duration: 5000,
        });
        return;
      }
      
      // Cálculos simples
      const custoTotal = custoProduto + frete;
      const lucro = valorVenda - custoTotal;
      const margemLucro = (lucro / valorVenda) * 100;
      
      // Calcular valor da parcela se for cartão de crédito
      let valorParcela = undefined;
      if (formData.formaPagamento === "Cartão de Crédito" && formData.quantidadeParcelas !== "1X") {
        const numParcelas = parseInt(formData.quantidadeParcelas.replace('X', ''));
        valorParcela = valorVenda / numParcelas;
      }
      
      // Atualizar resultado
      setCalculoResultado({
        valorFinal: valorVenda,
        lucro,
        margemLucro,
        valorParcela
      });
      
      // Mostrar toast de sucesso
      toast({
        title: "Cálculo realizado com sucesso!",
        description: "Confira abaixo os resultados da sua precificação.",
        variant: "default",
        duration: 5000,
      });
    } catch (error) {
      toast({
        title: "Erro ao calcular",
        description: "Ocorreu um erro ao processar os valores. Verifique e tente novamente.",
        variant: "destructive",
        duration: 5000,
      });
      console.error(error);
    }
  };

  // Exibir tela de splash enquanto as imagens carregam
  if (!imagesLoaded) {
    return <SplashScreen />;
  }

  return (
    <div className="min-h-screen">
      {/* Navegação */}
      <LandingNav scrolled={scrolled} />
      
      {/* Hero Section */}
      <section className="relative text-white pt-24">
        {/* Background gradiente semelhante ao da tela de login */}
        <div className="absolute inset-0 bg-gradient-to-br from-violet-700 via-purple-600 to-blue-600 z-0"></div>
        <div className="absolute inset-0 z-0" style={{ 
          backgroundImage: "radial-gradient(circle at 25% 25%, rgba(255, 255, 255, 0.2) 0%, transparent 50%), radial-gradient(circle at 75% 75%, rgba(255, 255, 255, 0.15) 0%, transparent 45%)" 
        }}></div>
        <div className="absolute inset-0 opacity-20 z-0" style={{ 
          backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" 
        }}></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-sm uppercase tracking-wider mb-2">TENHA LUCRO COM O MEU PREÇO CERTO</p>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Trabalha muito mas o<br />
                <span className="text-cyan-400">DINHEIRO SOME?</span>
              </h1>
              <p className="text-lg text-white mb-8">
                Você trabalha, trabalha e o dinheiro nunca sobra? O problema pode estar no preço que você 
                cobra — e nem percebe. Com o Meu Preço Certo, você precifica do jeito certo e transforma 
                esforço em lucro de verdade. Chega de trabalhar só pra sobreviver. Comece a lucrar de 
                verdade agora mesmo!
              </p>
              
              <div className="mt-8">
                <Button 
                  size="lg" 
                  className="bg-cyan-400 hover:bg-cyan-500 text-white rounded-full px-8"
                  onClick={() => navigate("/cadastre-se")}
                >
                  Quero Meu Preço Certo
                </Button>
              </div>
            </div>
            
            <div className="hidden lg:flex justify-center relative">
              <img 
                src={dashboardIllustration} 
                alt="Análise de preços" 
                className="w-full max-w-md object-contain"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Calculadora moderna de preços */}
      <section className="py-16 bg-gradient-to-b from-white to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center p-2 bg-purple-100 rounded-lg mb-4">
              <Calculator className="text-purple-600 mr-2" size={20} />
              <span className="text-sm font-medium text-purple-700">Meu Preço Certo</span>
            </div>
            <h2 className="text-3xl font-bold text-gray-900">Você está tendo tendo lucro com seu produto?</h2>
            <p className="mt-3 text-xl text-gray-600 max-w-3xl mx-auto">
              Simule rápido e descubra se esta tendo lucro ou prejuízo com seu produto.
            </p>
          </div>
          
          <div className="max-w-5xl mx-auto bg-white rounded-xl shadow-xl overflow-hidden">
            <div className="grid md:grid-cols-12 gap-0">
              {/* Dados do usuário */}
              <div className="md:col-span-4 bg-gradient-to-br from-purple-600 to-purple-800 p-8 text-white">
                <h3 className="text-xl font-medium mb-6">Seus Dados</h3>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-purple-100 mb-1">
                      Nome Completo
                    </label>
                    <Input
                      type="text"
                      id="nome"
                      name="nome"
                      value={formData.nome}
                      onChange={handleInputChange}
                      onBlur={handleInputBlur}
                      className={`w-full border-0 bg-white/20 text-white placeholder:text-purple-200 focus:ring-2 focus:ring-white ${!camposValidados.nome ? 'ring-2 ring-red-500' : ''}`}
                      placeholder="Seu nome"
                      required
                    />
                    {!camposValidados.nome && (
                      <p className="mt-1 text-red-300 text-xs flex items-center">
                        <AlertTriangle className="w-3 h-3 mr-1" /> Nome não pode estar vazio
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-purple-100 mb-1">
                      Email
                    </label>
                    <Input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      onBlur={handleInputBlur}
                      className={`w-full border-0 bg-white/20 text-white placeholder:text-purple-200 focus:ring-2 focus:ring-white ${!camposValidados.email ? 'ring-2 ring-red-500' : ''}`}
                      placeholder="seu@email.com"
                      required
                    />
                    {!camposValidados.email && (
                      <p className="mt-1 text-red-300 text-xs flex items-center">
                        <AlertTriangle className="w-3 h-3 mr-1" /> Formato de e-mail inválido
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-purple-100 mb-1">
                      Telefone
                    </label>
                    <Input
                      type="tel"
                      id="telefone"
                      name="telefone"
                      value={formData.telefone}
                      onChange={handleInputChange}
                      onBlur={handleInputBlur}
                      className={`w-full border-0 bg-white/20 text-white placeholder:text-purple-200 focus:ring-2 focus:ring-white ${!camposValidados.telefone ? 'ring-2 ring-red-500' : ''}`}
                      placeholder="(00) 00000-0000"
                      required
                    />
                    {!camposValidados.telefone && (
                      <p className="mt-1 text-red-300 text-xs flex items-center">
                        <AlertTriangle className="w-3 h-3 mr-1" /> Formato inválido, use (XX) XXXXX-XXXX
                      </p>
                    )}
                  </div>
                  
                  <div className="pt-4 mt-6">
                    <div className="flex items-center">
                      <Checkbox
                        id="termos"
                        checked={concordaTermos}
                        onCheckedChange={(checked) => setConcordaTermos(checked as boolean)}
                        className="mr-2 text-white bg-white/20 border-0 data-[state=checked]:bg-white data-[state=checked]:text-purple-700"
                      />
                      <label htmlFor="termos" className="text-sm text-purple-100">
                        Concordo com os <button type="button" onClick={() => setShowTermosModal(true)} className="text-white underline hover:text-purple-200 focus:outline-none">termos</button> e a <button type="button" onClick={() => setShowPrivacidadeModal(true)} className="text-white underline hover:text-purple-200 focus:outline-none">política de privacidade</button>
                      </label>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 pt-4 border-t border-purple-400/30">
                  <p className="text-sm text-purple-200">
                    <Info className="inline-block mr-2" size={16} />
                    Esta é uma simulação gratuita com funções limitadas. Para acessar todos os recursos e ferramentas avançadas de precificação, crie sua conta.                    
                  </p>
                  <Button 
                    variant="outline" 
                    className="mt-4 w-full bg-transparent text-white border-white hover:bg-white hover:text-purple-700"
                    onClick={() => navigate("/cadastre-se")}
                  >
                    Crie sua conta grátis
                  </Button>
                </div>
              </div>
              
              {/* Calculadora */}
              <div className="md:col-span-8 p-8">
                <div className="mb-6 flex justify-between items-center">
                  <h3 className="text-xl font-medium text-gray-900 flex items-center">
                    <Tag className="mr-2 text-purple-600" size={20} />
                    Calculadora de Preços
                  </h3>
                  
                  <div className="text-sm text-gray-500 flex items-center">
                    <span>Preencha os campos e obtenha o preço ideal</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Coluna 1: Informações Gerais */}
                  <div className="space-y-5">
                    {/* Custo do Produto */}
                    <div>
                      <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
                        <DollarSign className="mr-1 w-4 h-4 text-purple-500" />
                        Custo do Produto
                        <button 
                          type="button" 
                          className="ml-1 text-gray-400 hover:text-purple-600" 
                          onClick={() => mostrarAjuda('custoProduto')}
                        >
                          <HelpCircle size={14} />
                        </button>
                      </label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">R$</span>
                        <Input
                          type="text"
                          id="custoProduto"
                          name="custoProduto"
                          value={formData.custoProduto}
                          onChange={handleInputChange}
                          className="w-full pl-10 border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                          placeholder="0,00"
                          required
                        />
                      </div>
                    </div>
                    
                    {/* Frete */}
                    <div>
                      <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
                        <Truck className="mr-1 w-4 h-4 text-purple-500" />
                        Frete
                        <button 
                          type="button" 
                          className="ml-1 text-gray-400 hover:text-purple-600" 
                          onClick={() => mostrarAjuda('frete')}
                        >
                          <HelpCircle size={14} />
                        </button>
                      </label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">R$</span>
                        <Input
                          type="text"
                          id="frete"
                          name="frete"
                          value={formData.frete}
                          onChange={handleInputChange}
                          className="w-full pl-10 border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                          placeholder="0,00"
                        />
                      </div>
                    </div>
                    
                    {/* Margem de Lucro */}
                    <div>
                      <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
                        <Percent className="mr-1 w-4 h-4 text-purple-500" />
                        Margem de Lucro
                        <button 
                          type="button" 
                          className="ml-1 text-gray-400 hover:text-purple-600" 
                          onClick={() => toast({
                            title: "Margem de Lucro",
                            description: "Defina a porcentagem de lucro que deseja obter sobre o valor de venda.",
                            variant: "default",
                            duration: 5000,
                          })}
                        >
                          <HelpCircle size={14} />
                        </button>
                      </label>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="relative col-span-1">
                          <Input
                            type="text"
                            value={formData.lucroPercentual}
                            onChange={(e) => {
                              // Permitir apenas números
                              const value = e.target.value.replace(/\D/g, '');
                              setFormData({
                                ...formData,
                                lucroPercentual: value
                              });
                            }}
                            className="w-full pr-8 border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                            placeholder="30"
                          />
                          <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-500">%</span>
                        </div>
                        <div className="col-span-2">
                          <Select 
                            value={formData.tipoLucro}
                            onValueChange={(value) => {
                              setFormData({
                                ...formData,
                                tipoLucro: value
                              });
                            }}
                          >
                            <SelectTrigger className="border-gray-300 focus:border-purple-500 focus:ring-purple-500">
                              <SelectValue placeholder="Tipo" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="BRUTO">Sobre o preço bruto</SelectItem>
                              <SelectItem value="LIQUIDO">Sobre o preço líquido</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Coluna 2: Informações de Pagamento */}
                  <div className="space-y-5">
                    {/* Forma de Pagamento */}
                    <div>
                      <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
                        <CreditCard className="mr-1 w-4 h-4 text-purple-500" />
                        Forma de Pagamento
                        <button 
                          type="button" 
                          className="ml-1 text-gray-400 hover:text-purple-600" 
                          onClick={() => mostrarAjuda('formaPagamento')}
                        >
                          <HelpCircle size={14} />
                        </button>
                      </label>
                      <Select
                        value={formData.formaPagamento}
                        onValueChange={(value) => handleSelectChange("formaPagamento", value)}
                      >
                        <SelectTrigger className="border-gray-300 focus:border-purple-500 focus:ring-purple-500">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Dinheiro">Dinheiro</SelectItem>
                          <SelectItem value="Cartão de Crédito">Cartão de Crédito</SelectItem>
                          <SelectItem value="Cartão de Débito">Cartão de Débito</SelectItem>
                          <SelectItem value="Pix">Pix</SelectItem>
                          <SelectItem value="Boleto">Boleto</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* Parcelas (condicional) */}
                    {formData.formaPagamento === "Cartão de Crédito" && (
                      <div>
                        <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
                          <ArrowDownRight className="mr-1 w-4 h-4 text-purple-500" />
                          Parcelas
                          <button 
                            type="button" 
                            className="ml-1 text-gray-400 hover:text-purple-600" 
                            onClick={() => mostrarAjuda('quantidadeParcelas')}
                          >
                            <HelpCircle size={14} />
                          </button>
                        </label>
                        <Select
                          value={formData.quantidadeParcelas}
                          onValueChange={(value) => handleSelectChange("quantidadeParcelas", value)}
                        >
                          <SelectTrigger className="border-gray-300 focus:border-purple-500 focus:ring-purple-500">
                            <SelectValue placeholder="Número de parcelas" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1X">1x sem juros</SelectItem>
                            <SelectItem value="2X">2x sem juros</SelectItem>
                            <SelectItem value="3X">3x sem juros</SelectItem>
                            <SelectItem value="4X">4x sem juros</SelectItem>
                            <SelectItem value="5X">5x sem juros</SelectItem>
                            <SelectItem value="6X">6x sem juros</SelectItem>
                            <SelectItem value="7X">7x com juros</SelectItem>
                            <SelectItem value="8X">8x com juros</SelectItem>
                            <SelectItem value="9X">9x com juros</SelectItem>
                            <SelectItem value="10X">10x com juros</SelectItem>
                            <SelectItem value="11X">11x com juros</SelectItem>
                            <SelectItem value="12X">12x com juros</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                    
                    {/* Valor de Venda */}
                    <div>
                      <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
                        <Tag className="mr-1 w-4 h-4 text-purple-500" />
                        Valor de Venda
                        <button 
                          type="button" 
                          className="ml-1 text-gray-400 hover:text-purple-600" 
                          onClick={() => mostrarAjuda('valorVenda')}
                        >
                          <HelpCircle size={14} />
                        </button>
                      </label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">R$</span>
                        <Input
                          type="text"
                          id="valorVenda"
                          name="valorVenda"
                          value={formData.valorVenda}
                          onChange={handleInputChange}
                          className="w-full pl-10 border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                          placeholder="0,00"
                          required
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Botão de cálculo */}
                <div className="mt-6">
                  <Button 
                    onClick={handleCalcular}
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white py-6 rounded-lg shadow-md transition-all transform hover:translate-y-[-2px] text-lg font-medium"
                    disabled={!isFormValid()}
                  >
                    CALCULAR MEU PREÇO IDEAL
                    <Calculator className="ml-2" size={18} />
                  </Button>
                </div>
                
                {/* Resultados */}
                {calculoResultado && (
                  <div className="mt-8 pt-6 border-t border-gray-200">
                    <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                      <DollarSign className="mr-2 text-purple-600" size={18} />
                      Resultado da Análise
                    </h4>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">Valor de Venda</div>
                        <div className="flex items-center justify-between">
                          <div className="text-2xl font-bold text-gray-900">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(calculoResultado.valorFinal)}
                          </div>
                          <button
                            type="button"
                            className="p-1.5 bg-white rounded-full border border-gray-200 text-gray-500 hover:text-purple-600 hover:border-purple-300"
                            onClick={() => copiarValor(new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(calculoResultado.valorFinal), "Valor de venda")}
                          >
                            <Clipboard size={14} />
                          </button>
                        </div>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">Lucro</div>
                        <div className="flex items-center justify-between">
                          <div className="text-2xl font-bold text-gray-900">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(calculoResultado.lucro)}
                          </div>
                          <button
                            type="button"
                            className="p-1.5 bg-white rounded-full border border-gray-200 text-gray-500 hover:text-purple-600 hover:border-purple-300"
                            onClick={() => copiarValor(new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(calculoResultado.lucro), "Valor do lucro")}
                          >
                            <Clipboard size={14} />
                          </button>
                        </div>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">Margem de Lucro</div>
                        <div className="flex items-center justify-between">
                          <div className="text-2xl font-bold text-gray-900">
                            {calculoResultado.margemLucro.toFixed(2)}%
                          </div>
                          <button
                            type="button"
                            className="p-1.5 bg-white rounded-full border border-gray-200 text-gray-500 hover:text-purple-600 hover:border-purple-300"
                            onClick={() => copiarValor(`${calculoResultado.margemLucro.toFixed(2)}%`, "Margem de lucro")}
                          >
                            <Clipboard size={14} />
                          </button>
                        </div>
                      </div>
                      
                      {calculoResultado.valorParcela && (
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <div className="text-sm text-gray-500 mb-1">Valor da Parcela</div>
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="text-2xl font-bold text-gray-900">
                                {formData.quantidadeParcelas} de {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(calculoResultado.valorParcela !== undefined ? calculoResultado.valorParcela : 0)}
                              </div>
                            </div>
                            <button
                              type="button"
                              className="p-1.5 bg-white rounded-full border border-gray-200 text-gray-500 hover:text-purple-600 hover:border-purple-300"
                              onClick={() => copiarValor(`${formData.quantidadeParcelas} de ${new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(calculoResultado.valorParcela !== undefined ? calculoResultado.valorParcela : 0)}`, "Valor da parcela")}
                            >
                              <Clipboard size={14} />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seção 3 - Removida conforme solicitado */}
      <section className="py-16 bg-gradient-to-r from-purple-500 via-purple-600 to-purple-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Conteúdo removido conforme solicitação */}
        </div>
      </section>
      
      {/* Componente Toaster para exibir notificações */}
      <Toaster />
      
      {/* Modal de Termos de Uso */}
      <Dialog open={showTermosModal} onOpenChange={setShowTermosModal}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center text-xl font-semibold text-gray-900">
              <FileText className="mr-2 text-purple-600" size={22} />
              Termos de Uso
            </DialogTitle>
            <DialogDescription className="text-gray-500">
              Leia com atenção os termos de uso da plataforma Meu Preço Certo
            </DialogDescription>
          </DialogHeader>
          
          <div className="mt-4 space-y-4 text-gray-700">
            <h3 className="text-lg font-semibold text-gray-900">1. Aceitação dos Termos</h3>
            <p>
              Ao acessar e utilizar a plataforma Meu Preço Certo, você concorda em cumprir e ficar vinculado aos presentes Termos 
              de Uso. Se você não concordar com algum dos termos, não utilize nossos serviços.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">2. Descrição do Serviço</h3>
            <p>
              O Meu Preço Certo é uma plataforma online que fornece ferramentas para cálculo de preços de produtos e serviços, 
              auxílio na precificação, e gestão de custos para pequenos e médios empreendedores.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">3. Cadastro e Conta</h3>
            <p>
              3.1. Para acessar todas as funcionalidades da plataforma, é necessário criar uma conta fornecendo informações precisas e atualizadas.<br />
              3.2. Você é responsável por manter a confidencialidade de sua senha e por todas as atividades realizadas com sua conta.<br />
              3.3. Você concorda em notificar imediatamente qualquer uso não autorizado de sua conta.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">4. Uso da Plataforma</h3>
            <p>
              4.1. Você concorda em não usar a plataforma para fins ilegais ou não autorizados.<br />
              4.2. Você não pode tentar obter acesso não autorizado a outros sistemas ou redes conectados à plataforma.<br />
              4.3. A plataforma é para uso pessoal ou empresarial, conforme o plano contratado.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">5. Propriedade Intelectual</h3>
            <p>
              5.1. Todo o conteúdo disponibilizado na plataforma, como textos, gráficos, logotipos, imagens, bem como a compilação de todo o conteúdo, 
              são propriedade do Meu Preço Certo ou de seus fornecedores de conteúdo e protegidos por leis de direitos autorais.<br />
              5.2. Você não está autorizado a modificar, reproduzir, publicar, licenciar, criar trabalhos derivados ou vender qualquer informação obtida a partir da plataforma.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">6. Limitação de Responsabilidade</h3>
            <p>
              6.1. A plataforma é fornecida "como está" e "conforme disponível", sem garantias de qualquer tipo.<br />
              6.2. Em nenhuma circunstância, o Meu Preço Certo será responsável por danos diretos, indiretos, incidentais, especiais ou consequentes resultantes do uso da plataforma.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">7. Alterações nos Termos</h3>
            <p>
              Reservamo-nos o direito de modificar estes termos a qualquer momento. As alterações entrarão em vigor após a publicação dos termos atualizados na plataforma. 
              O uso contínuo da plataforma após tais alterações constitui sua aceitação dos novos termos.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">8. Rescisão</h3>
            <p>
              Podemos encerrar ou suspender o acesso à nossa plataforma imediatamente, sem aviso prévio, por qualquer motivo, incluindo, sem limitação, 
              se você violar os Termos de Uso.
            </p>
            
            <p className="text-sm text-gray-500 mt-6">
              Última atualização: 2 de maio de 2025
            </p>
          </div>
          
          <DialogFooter>
            <Button 
              onClick={() => setShowTermosModal(false)}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Entendi e Concordo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Modal de Política de Privacidade */}
      <Dialog open={showPrivacidadeModal} onOpenChange={setShowPrivacidadeModal}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center text-xl font-semibold text-gray-900">
              <Shield className="mr-2 text-purple-600" size={22} />
              Política de Privacidade
            </DialogTitle>
            <DialogDescription className="text-gray-500">
              Como utilizamos e protegemos seus dados
            </DialogDescription>
          </DialogHeader>
          
          <div className="mt-4 space-y-4 text-gray-700">
            <h3 className="text-lg font-semibold text-gray-900">1. Informações Coletadas</h3>
            <p>
              1.1. <strong>Informações de cadastro:</strong> ao criar uma conta, coletamos seu nome, e-mail e telefone para identificação e contato.<br />
              1.2. <strong>Dados de uso:</strong> coletamos informações sobre como você utiliza nossa plataforma, incluindo produtos cadastrados, 
              cálculos realizados e configurações de preferência.<br />
              1.3. <strong>Informações financeiras:</strong> para fins de precificação, você pode inserir dados como custos de produtos, serviços 
              e outras informações financeiras relevantes.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">2. Uso das Informações</h3>
            <p>
              2.1. Utilizamos suas informações para:<br />
              - Fornecer, manter e melhorar nossos serviços<br />
              - Personalizar sua experiência na plataforma<br />
              - Processar transações e enviar notificações relacionadas<br />
              - Responder a suas solicitações e fornecer suporte<br />
              - Enviar atualizações, alertas e informativos (com sua permissão)
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">3. Compartilhamento de Informações</h3>
            <p>
              3.1. Não vendemos, alugamos ou compartilhamos suas informações pessoais com terceiros para fins de marketing.<br />
              3.2. Podemos compartilhar informações nas seguintes circunstâncias:<br />
              - Com provedores de serviços que nos auxiliam na operação da plataforma<br />
              - Quando exigido por lei ou para proteger nossos direitos<br />
              - Em caso de fusão, venda ou transferência de ativos (mantendo as proteções desta política)
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">4. Segurança das Informações</h3>
            <p>
              4.1. Implementamos medidas de segurança técnicas e organizacionais para proteger suas informações contra acesso não autorizado, 
              alteração, divulgação ou destruição.<br />
              4.2. As informações são armazenadas em servidores seguros e utilizamos criptografia para dados sensíveis.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">5. Seus Direitos</h3>
            <p>
              5.1. Você tem o direito de:<br />
              - Acessar, corrigir ou excluir seus dados pessoais<br />
              - Restringir ou se opor ao processamento de seus dados<br />
              - Solicitar a portabilidade de seus dados<br />
              - Revogar o consentimento a qualquer momento
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">6. Retenção de Dados</h3>
            <p>
              Mantemos suas informações pessoais pelo tempo necessário para fornecer os serviços solicitados e cumprir nossas obrigações legais. 
              Após este período, excluímos ou anonimizamos suas informações.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">7. Alterações na Política</h3>
            <p>
              Podemos atualizar esta Política de Privacidade periodicamente. Notificaremos você sobre alterações significativas 
              através de um aviso em nossa plataforma ou por e-mail.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900">8. Contato</h3>
            <p>
              Se você tiver dúvidas ou preocupações sobre nossa Política de Privacidade ou práticas de dados, entre em contato conosco 
              pelo e-mail: privacidade@meuprecocerto.com.br
            </p>
            
            <p className="text-sm text-gray-500 mt-6">
              Última atualização: 2 de maio de 2025
            </p>
          </div>
          
          <DialogFooter>
            <Button 
              onClick={() => setShowPrivacidadeModal(false)}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Entendi e Concordo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}