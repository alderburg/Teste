import React from "react";
import { Check, X, Circle } from "lucide-react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

// Função para formatar o preço com separador de milhares
const formatPrice = (price: string | number): string => {
  return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
};

export default function PlanosEUpgradesPage() {
  const [, navigate] = useLocation();
  const [periodo, setPeriodo] = React.useState<"mensal" | "anual">("mensal");

  // Definição dos planos de acordo com a imagem
  const planos = [
    {
      nome: "Gratuito",
      precoAntigo: "",
      preco: "0",
      cor: "bg-white",
      corTexto: "text-gray-900",
      destaque: false,
      caracteristicas: {
        produtos: "500 produtos ativos",
        vendas: "R$ 5.000 vendas/mês"
      },
      botaoLabel: "Criar minha loja",
      botaoCor: "bg-teal-500 hover:bg-teal-600 text-white",
      produtosGratis: "30",
      enrichment: "Produtos Grátis"
    },
    {
      nome: "Crescimento",
      precoAntigo: "R$ 79",
      preco: "43",
      cor: "bg-white",
      corTexto: "text-gray-900",
      destaque: false,
      caracteristicas: {
        produtos: "250 produtos ativos",
        vendas: "R$ 25.000 vendas/mês"
      },
      botaoLabel: "Criar minha loja",
      botaoCor: "bg-teal-500 hover:bg-teal-600 text-white",
      produtosGratis: "30",
      enrichment: "Produtos Grátis"
    },
    {
      nome: "Aceleração",
      precoAntigo: "R$ 99",
      preco: "79",
      cor: "bg-purple-900",
      corTexto: "text-white",
      destaque: true,
      caracteristicas: {
        produtos: "500 produtos ativos",
        vendas: "R$ 75.000 vendas/mês"
      },
      botaoLabel: "Criar minha loja",
      botaoCor: "bg-teal-500 hover:bg-teal-600 text-white",
      produtosGratis: "50",
      enrichment: "Produtos Grátis"
    },
    {
      nome: "Expansão",
      precoAntigo: "R$ 239",
      preco: "191",
      cor: "bg-white",
      corTexto: "text-gray-900",
      destaque: false,
      caracteristicas: {
        produtos: "Produtos ilimitados",
        vendas: "R$ 300.000 vendas/mês"
      },
      botaoLabel: "Criar minha loja",
      botaoCor: "bg-teal-500 hover:bg-teal-600 text-white",
      produtosGratis: "50",
      enrichment: "Produtos Grátis + Enriquecimento em Massa"
    },
    {
      nome: "Elite",
      precoAntigo: "R$ 1999",
      preco: "1599",
      cor: "bg-white",
      corTexto: "text-gray-900",
      destaque: false,
      caracteristicas: {
        produtos: "Produtos ilimitados",
        vendas: "Vendas ilimitadas"
      },
      botaoLabel: "Criar minha loja",
      botaoCor: "bg-teal-500 hover:bg-teal-600 text-white",
      produtosGratis: "100",
      enrichment: "Produtos Grátis + Enriquecimento em Massa"
    }
  ];

  // Características das funcionalidades
  const features = [
    { id: "loja_online", label: "Loja Online Completa" },
    { id: "tarifa_pag", label: "Tarifa grátis com Paggi" },
    { id: "correios", label: "Correios até 70% mais barato com Envio!" },
    { id: "suporte", label: "Suporte humanizado por chat e e-mail" },
    { id: "mais_vendas", label: "Mais vendas com recuperador de Carrinho Abandonado" },
    { id: "mais_conversao", label: "Mais conversão com Checkout Otimizado + Acesso ao Smartwix" },
    { id: "ticket_medio", label: "Ticket médio até 29% maior com PromoCodes e Compra junto" },
    { id: "gerente", label: "Gerente de Performance dedicado" },
    { id: "ia", label: "Aumente seu tráfego orgânico com a IA da Insira AI" }
  ];

  // Tipo para as funcionalidades de cada plano
  type FeatureSet = {
    loja_online: boolean;
    tarifa_pag: boolean;
    correios: boolean;
    suporte: boolean;
    mais_vendas: boolean;
    mais_conversao: boolean;
    ticket_medio: boolean;
    gerente: boolean;
    ia: boolean;
  }

  // Tipo para o objeto que mapeia nomes de planos para seus recursos
  type PlanFeatures = {
    [key: string]: FeatureSet;
  }

  // Informações de recursos por tipo de plano (true, false)
  const featuresByPlan: PlanFeatures = {
    "Gratuito": {
      loja_online: true,
      tarifa_pag: true,
      correios: true,
      suporte: false,
      mais_vendas: false,
      mais_conversao: false,
      ticket_medio: false,
      gerente: false,
      ia: false
    },
    "Crescimento": {
      loja_online: true,
      tarifa_pag: true,
      correios: true,
      suporte: true,
      mais_vendas: true,
      mais_conversao: true,
      ticket_medio: true,
      gerente: false,
      ia: false
    },
    "Aceleração": {
      loja_online: true,
      tarifa_pag: true,
      correios: true,
      suporte: true,
      mais_vendas: true,
      mais_conversao: true,
      ticket_medio: true,
      gerente: true,
      ia: false
    },
    "Expansão": {
      loja_online: true,
      tarifa_pag: true,
      correios: true,
      suporte: true,
      mais_vendas: true,
      mais_conversao: true,
      ticket_medio: true,
      gerente: true,
      ia: true
    },
    "Elite": {
      loja_online: true,
      tarifa_pag: true,
      correios: true,
      suporte: true,
      mais_vendas: true,
      mais_conversao: true,
      ticket_medio: true,
      gerente: true,
      ia: true
    }
  };

  return (
    <div className="py-12 px-4 sm:px-6 lg:px-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Cabeçalho */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-purple-900 mb-6">
            +2.5 milhões de lojistas já escolheram
            <br />um plano ideal. Escolha o seu também!
          </h1>
          
          {/* Seletor de período */}
          <div className="flex justify-center items-center space-x-4 mb-4">
            <Button
              variant={periodo === "mensal" ? "default" : "outline"}
              onClick={() => setPeriodo("mensal")}
              className={`${periodo === "mensal" ? "bg-purple-900" : "bg-white text-gray-700"}`}
            >
              Mensal
            </Button>
            
            <Button
              variant={periodo === "anual" ? "default" : "outline"}
              onClick={() => setPeriodo("anual")}
              className={`${periodo === "anual" ? "bg-purple-900" : "bg-white text-gray-700"}`}
            >
              Anual
            </Button>
          </div>
          
          <Badge className="bg-purple-900 text-white rounded-full py-1 px-4">
            Economize 20% OFF e parcele em até 6x sem juros
          </Badge>
        </div>
        
        {/* Cards de Planos */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 mb-8">
          {planos.map((plano, index) => (
            <Card 
              key={index}
              className={`overflow-hidden flex flex-col h-full ${plano.destaque ? 'ring-2 ring-purple-600' : 'border border-gray-200'}`}
            >
              <CardContent className={`p-0 ${plano.cor} flex flex-col flex-grow`}>
                {/* Cabeçalho do plano */}
                <div className={`px-4 py-6 text-center ${plano.corTexto} flex flex-col h-full`}>
                  <div>
                    <h3 className="text-lg font-medium mb-1">{plano.nome}</h3>
                    {plano.precoAntigo && (
                      <p className="text-sm line-through opacity-70 mb-1">{plano.precoAntigo}/{periodo === "mensal" ? "mês" : "ano"}</p>
                    )}
                    <div className="flex items-baseline justify-center">
                      <span className="text-3xl font-bold">R$ {formatPrice(periodo === "anual" && plano.nome !== "Gratuito" ? parseInt(plano.preco) * 10 : plano.preco)}</span>
                      <span className="text-sm ml-1">/{periodo === "mensal" ? "mês" : "ano"}</span>
                    </div>
                    
                    {/* Características */}
                    <div className="mt-4 text-sm">
                      <p>{plano.caracteristicas.produtos}</p>
                      <p>{plano.caracteristicas.vendas}</p>
                    </div>
                  </div>
                  
                  {/* Espaçador flexível para empurrar o botão para baixo */}
                  <div className="flex-grow mt-4"></div>
                  
                  {/* Botão de ação */}
                  <Button 
                    className={`w-full mt-4 ${plano.botaoCor}`}
                    onClick={() => navigate("/signup")}
                  >
                    {plano.botaoLabel}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Tabela de comparação de funcionalidades */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden mt-8">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50">
                  <th className="py-4 px-6 text-left text-sm font-medium text-gray-500 border-b border-gray-200 w-1/4">
                    Funcionalidades
                  </th>
                  {planos.map((plano, index) => (
                    <th 
                      key={index}
                      className={`text-center py-4 px-2 text-sm font-medium ${
                        plano.destaque ? 'bg-purple-900 text-white' : 'text-gray-500 bg-gray-50'
                      } border-b border-gray-200`}
                    >
                      {plano.nome}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {features.map((feature, featureIndex) => (
                  <tr key={featureIndex} className={featureIndex % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="py-3 px-6 text-sm text-gray-500 border-b border-gray-200">
                      {feature.label}
                    </td>
                    
                    {planos.map((plano, planoIndex) => {
                      const isAvailable = featuresByPlan[plano.nome][feature.id as keyof FeatureSet];
                      return (
                        <td 
                          key={planoIndex}
                          className={`text-center py-3 px-2 text-sm border-b border-gray-200 ${
                            plano.destaque ? 'bg-purple-900 bg-opacity-5' : ''
                          }`}
                        >
                          {isAvailable ? (
                            <div className="flex justify-center">
                              <Check className="h-5 w-5 text-teal-500" />
                            </div>
                          ) : (
                            <div className="flex justify-center">
                              <X className="h-5 w-5 text-red-500" />
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
                
                {/* Linha de produtos grátis */}
                <tr className="bg-gray-100">
                  <td className="py-4 px-6 text-sm font-medium text-gray-800 border-b border-gray-200">
                    Produtos Grátis
                  </td>
                  {planos.map((plano, index) => (
                    <td 
                      key={index}
                      className={`text-center py-4 px-2 text-sm font-medium border-b border-gray-200 ${
                        plano.destaque ? 'bg-purple-800 text-white' : 'text-gray-800 bg-gray-100'
                      }`}
                    >
                      {plano.produtosGratis}
                    </td>
                  ))}
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <td className="py-4 px-6 text-sm font-medium text-gray-800 border-t border-gray-200">
                    Produtos Grátis + Enriquecimento
                  </td>
                  {planos.map((plano, index) => (
                    <td 
                      key={index}
                      className={`text-center py-4 px-2 text-sm border-t border-gray-200 ${
                        plano.destaque ? 'bg-purple-900 bg-opacity-10 font-medium' : ''
                      }`}
                    >
                      {plano.enrichment}
                    </td>
                  ))}
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}