import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const CountdownTimer = () => {
  const [countdown, setCountdown] = useState(30);

  useEffect(() => {
    setCountdown(30 - (Math.floor(Date.now() / 1000) % 30));

    const timer = setInterval(() => {
      const newCountdown = 30 - (Math.floor(Date.now() / 1000) % 30);
      setCountdown(newCountdown);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="text-center text-sm text-gray-500 mb-4">
      Atualiza em: {countdown}s
    </div>
  );
};

import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { 
  User, Camera, Save, Upload, ArrowLeft, Loader2, 
  MapPin, CreditCard, FileText, Shield, Edit3,
  Building, Users, CheckCircle, CreditCard as CreditCardIcon,
  Download, DollarSign, Calendar, Badge
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

// Componente para exibir mensagens de erro
const FormErrorMessage = ({ message }: { message: string }) => (
  <div className="text-sm font-medium text-destructive mt-1">{message}</div>
);

// Esquema de validação para dados pessoais
const perfilSchema = z.object({
  logoUrl: z.string().optional(),
  primeiroNome: z.string().min(1, { message: "O primeiro nome é obrigatório" }),
  ultimoNome: z.string().min(1, { message: "O último nome é obrigatório" }),
  razaoSocial: z.string().optional(),
  nomeFantasia: z.string().optional(),
  tipoPessoa: z.string().min(1, { message: "O tipo de pessoa é obrigatório" }),
  cpfCnpj: z.string().min(1, { message: "CPF/CNPJ é obrigatório" }),
  inscricaoEstadual: z.string().optional(),
  inscricaoMunicipal: z.string().optional(),
  cnae: z.string().optional(),
  regimeTributario: z.string().optional(),
  atividadePrincipal: z.string().optional(),

  // Responsável
  responsavelNome: z.string().min(1, { message: "O nome do responsável é obrigatório" }),
  responsavelEmail: z.string().email("Email inválido").min(1, { message: "O email do responsável é obrigatório" }),
  responsavelTelefone: z.string().min(1, { message: "O telefone do responsável é obrigatório" }),
  responsavelSetor: z.string().optional(),

  // Contador
  contadorNome: z.string().optional(),
  contadorEmail: z.string().email("Email inválido").optional().or(z.literal("")),
  contadorTelefone: z.string().optional(),
});

// Esquema de validação para endereço e contatos
const enderecoSchema = z.object({
  cep: z.string().min(1, { message: "CEP é obrigatório" }),
  logradouro: z.string().min(1, { message: "Logradouro é obrigatório" }),
  numero: z.string().min(1, { message: "Número é obrigatório" }),
  complemento: z.string().optional(),
  bairro: z.string().min(1, { message: "Bairro é obrigatório" }),
  cidade: z.string().min(1, { message: "Cidade é obrigatória" }),
  estado: z.string().min(1, { message: "Estado é obrigatório" }),

  // Contatos
  telefone: z.string().min(1, { message: "Telefone é obrigatório" }),
  celular: z.string().optional(),
  whatsapp: z.string().optional(),
  email: z.string().email("Email inválido").min(1, { message: "Email é obrigatório" }),
  website: z.string().optional(),

  // Para campos secundários adicionais
  telefoneSec: z.string().optional(),
  emailSec: z.string().email("Email inválido").optional().or(z.literal("")),
  whatsappSec: z.string().optional(),
});

type PerfilFormValues = z.infer<typeof perfilSchema>;
type EnderecoFormValues = z.infer<typeof enderecoSchema>;

export default function MinhaContaPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("dados");
  const [isUploading, setIsUploading] = useState(false);
  const [showAddCard, setShowAddCard] = useState(false);
  const [showAddContact, setShowAddContact] = useState(false);
  const [showPasswordSection, setShowPasswordSection] = useState(false);
  const [show2FASection, setShow2FASection] = useState(false); // Added state for password section

  // Gerenciamento de erros específicos dos campos
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const perfilForm = useForm<PerfilFormValues>({
    resolver: zodResolver(perfilSchema),
    defaultValues: {
      logoUrl: user?.logoUrl || "",
      primeiroNome: "",
      ultimoNome: "",
      razaoSocial: "",
      nomeFantasia: "",
      tipoPessoa: "fisica",
      cpfCnpj: "",
      inscricaoEstadual: "",
      inscricaoMunicipal: "",
      cnae: "",
      regimeTributario: "mei",
      atividadePrincipal: "",

      // Responsável
      responsavelNome: "",
      responsavelEmail: "",
      responsavelTelefone: "",
      responsavelSetor: "Administrativa",

      // Contador
      contadorNome: "",
      contadorEmail: "",
      contadorTelefone: "",
    },
    mode: "onSubmit",
  });

  const enderecoForm = useForm<EnderecoFormValues>({
    resolver: zodResolver(enderecoSchema),
    defaultValues: {
      cep: "",
      logradouro: "",
      numero: "",
      complemento: "",
      bairro: "",
      cidade: "",
      estado: "",

      // Contatos
      telefone: "",
      celular: "",
      whatsapp: "",
      email: "",
      website: "",

      // Contatos secundários
      telefoneSec: "",
      emailSec: "",
      whatsappSec: "",
    },
    mode: "onSubmit",
  });

  // Fetch user profile data
  const { data: perfilData, isLoading: isLoadingPerfil } = useQuery({
    queryKey: ["/api/minha-conta/perfil", user?.id],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/minha-conta/perfil?userId=${user?.id || 0}`);
      return res.json();
    },
    enabled: !!user,
  });

  // Mutation para atualizar dados do perfil
  const updatePerfilMutation = useMutation({
    mutationFn: async (data: PerfilFormValues) => {
      const res = await apiRequest("PUT", `/api/minha-conta/perfil/${user?.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Perfil atualizado",
        description: "Seus dados foram atualizados com sucesso",
        variant: "default",
        className: "bg-white border-gray-200",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/minha-conta/perfil"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao atualizar perfil",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation para atualizar endereço
  const updateEnderecoMutation = useMutation({
    mutationFn: async (data: EnderecoFormValues) => {
      const res = await apiRequest("PUT", `/api/minha-conta/perfil/${user?.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Endereço atualizado",
        description: "Seus dados de endereço foram atualizados com sucesso",
        variant: "default",
        className: "bg-white border-gray-200",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/minha-conta/perfil"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao atualizar endereço",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation para upload de logo
  const uploadLogoMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await apiRequest("POST", `/api/minha-conta/upload-logo`, formData);
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Logo atualizado",
        description: "Seu logo foi atualizado com sucesso",
        variant: "default",
        className: "bg-white border-gray-200",
      });
      perfilForm.setValue("logoUrl", data.logoUrl);
      queryClient.invalidateQueries({ queryKey: ["/api/minha-conta/perfil"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao fazer upload do logo",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Atualiza o formulário quando os dados do perfil são carregados
  useEffect(() => {
    if (perfilData) {
      // Atualiza o formulário de perfil
      Object.keys(perfilForm.getValues()).forEach((key) => {
        if (key in perfilData) {
          perfilForm.setValue(key as any, perfilData[key]);
        }
      });

      // Atualiza o formulário de endereço
      Object.keys(enderecoForm.getValues()).forEach((key) => {
        if (key in perfilData) {
          enderecoForm.setValue(key as any, perfilData[key]);
        }
      });
    }
  }, [perfilData, perfilForm, enderecoForm]);

  // Função para lidar com upload de imagem
  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validação de tipo e tamanho
    const validTypes = ['image/jpeg', 'image/png', 'image/gif'];
    const maxSize = 5 * 1024 * 1024; // 5MB

    if (!validTypes.includes(file.type)) {
      toast({
        title: "Formato inválido",
        description: "Por favor, envie uma imagem nos formatos JPG, PNG ou GIF.",
        variant: "destructive",
      });
      return;
    }

    if (file.size > maxSize) {
      toast({
        title: "Arquivo muito grande",
        description: "O tamanho máximo permitido é 5MB.",
        variant: "destructive",
      });
      return;
    }

    // Upload do arquivo
    setIsUploading(true);
    const formData = new FormData();
    formData.append('logo', file);
    formData.append('userId', user?.id?.toString() || "0");

    uploadLogoMutation.mutate(formData);
    setIsUploading(false);
  };

  // Função para remover o logo
  const handleRemoveLogo = () => {
    if (window.confirm("Tem certeza que deseja remover seu logo?")) {
      perfilForm.setValue("logoUrl", "");
      const data = perfilForm.getValues();
      updatePerfilMutation.mutate(data);
    }
  };

  // Função para salvar o formulário de perfil
  const handleSavePerfil = (formData: PerfilFormValues) => {
    try {
      updatePerfilMutation.mutate(formData);
    } catch (error: any) {
      toast({
        title: "Erro ao salvar dados",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Função para salvar o formulário de endereço
  const handleSaveEndereco = (formData: EnderecoFormValues) => {
    try {
      updateEnderecoMutation.mutate(formData);
    } catch (error: any) {
      toast({
        title: "Erro ao salvar endereço",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Função para renderizar ícone da aba
  const renderTabIcon = (tab: string) => {
    switch (tab) {
      case "dados":
        return <User className="h-4 w-4" />;
      case "endereco":
        return <MapPin className="h-4 w-4" />;
      case "usuarios":
        return <Users className="h-4 w-4" />;
      case "financeiro":
        return <CreditCard className="h-4 w-4" />;
      case "seguranca":
        return <Shield className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen flex-1 w-full">
      <div className="container mx-auto px-4 py-6 max-w-[1600px]">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Minha Conta</h2>
              <p className="text-gray-500">
                Gerencie suas informações pessoais e configurações
              </p>
            </div>
          </div>

          <Tabs 
            defaultValue="dados" 
            value={activeTab} 
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList className="grid grid-cols-1 md:grid-cols-5 w-full mb-4 h-auto border-b rounded-none bg-transparent">
              <TabsTrigger 
                value="dados" 
                className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-600 rounded-none bg-transparent hover:bg-transparent data-[state=active]:bg-transparent px-4 py-3"
              >
                {renderTabIcon("dados")}
                <span>Dados de Cadastro</span>
              </TabsTrigger>
              <TabsTrigger 
                value="endereco" 
                className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-600 rounded-none bg-transparent hover:bg-transparent data-[state=active]:bg-transparent px-4 py-3"
              >
                {renderTabIcon("endereco")}
                <span>Endereço / Contatos</span>
              </TabsTrigger>
              <TabsTrigger 
                value="usuarios" 
                className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-600 rounded-none bg-transparent hover:bg-transparent data-[state=active]:bg-transparent px-4 py-3"
              >
                {renderTabIcon("usuarios")}
                <span>Usuários</span>
              </TabsTrigger>
              <TabsTrigger 
                value="financeiro" 
                className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-600 rounded-none bg-transparent hover:bg-transparent data-[state=active]:bg-transparent px-4 py-3"
              >
                {renderTabIcon("financeiro")}
                <span>Financeiro</span>
              </TabsTrigger>
              <TabsTrigger 
                value="seguranca" 
                className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-600 rounded-none bg-transparent hover:bg-transparent data-[state=active]:bg-transparent px-4 py-3"
              >
                {renderTabIcon("seguranca")}
                <span>Segurança da Conta</span>
              </TabsTrigger>
            </TabsList>

            {/* Tab: Dados de Cadastro */}
            <TabsContent value="dados" className="space-y-4">
              <Card className="shadow-sm">
                <CardContent className="pt-6">
                  <Form {...perfilForm}>
                    <form onSubmit={perfilForm.handleSubmit(handleSavePerfil)} className="space-y-6">
                      <div className="space-y-4">
                        {/* Logo Upload Section */}
                        <div>
                          <Label>Logo:</Label>
                          <div className="flex items-end gap-4 mt-2">
                            <div className="relative">
                              <Avatar className="w-20 h-20">
                                {perfilForm.watch("logoUrl") ? (
                                  <AvatarImage src={perfilForm.watch("logoUrl")} alt="Logo" />
                                ) : (
                                  <AvatarFallback className="bg-purple-100 text-purple-600 text-xl">
                                    {user?.primeiroNome?.charAt(0) || "U"}
                                  </AvatarFallback>
                                )}
                              </Avatar>
                              <label 
                                htmlFor="logo-upload" 
                                className="absolute -right-2 -bottom-2 bg-purple-600 rounded-full p-1 cursor-pointer hover:bg-purple-700 transition-colors"
                              >
                                <Camera className="h-4 w-4 text-white" />
                                <input 
                                  id="logo-upload" 
                                  type="file" 
                                  accept="image/*" 
                                  className="hidden" 
                                  onChange={handleLogoUpload}
                                />
                              </label>
                            </div>
                            <div className="flex gap-2">
                              <Button 
                                type="button"
                                variant="secondary"
                                size="sm"
                                onClick={() => {
                                  document.getElementById("logo-upload")?.click();
                                }}
                                disabled={isUploading}
                                className="text-xs h-8"
                              >
                                {isUploading ? (
                                  <>
                                    <Loader2 className="mr-2 h-3 w-3 animate-spin" />
                                    Atualizando...
                                  </>
                                ) : "Atualizar"}
                              </Button>
                              {perfilForm.watch("logoUrl") && (
                                <Button 
                                  type="button"
                                  variant="destructive" 
                                  size="sm"
                                  className="text-xs h-8"
                                  onClick={handleRemoveLogo}
                                >
                                  Remover
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={perfilForm.control}
                            name="primeiroNome"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>
                                  Primeiro Nome <span className="text-red-500">*</span>
                                </FormLabel>
                                <FormControl>
                                  <Input placeholder="Digite seu primeiro nome" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={perfilForm.control}
                            name="ultimoNome"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>
                                  Último Nome <span className="text-red-500">*</span>
                                </FormLabel>
                                <FormControl>
                                  <Input placeholder="Digite seu último nome" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={perfilForm.control}
                            name="tipoPessoa"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>
                                  Tipo de Pessoa <span className="text-red-500">*</span>
                                </FormLabel>
                                <Select 
                                  value={field.value} 
                                  onValueChange={field.onChange}
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Selecione o tipo de pessoa" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="fisica">Pessoa Física</SelectItem>
                                    <SelectItem value="juridica">Pessoa Jurídica</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={perfilForm.control}
                            name="cpfCnpj"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>
                                  {perfilForm.watch("tipoPessoa") === "fisica" ? "CPF" : "CNPJ"} <span className="text-red-500">*</span>
                                </FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder={perfilForm.watch("tipoPessoa") === "fisica" ? "Digite seu CPF" : "Digite o CNPJ"} 
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        {perfilForm.watch("tipoPessoa") === "juridica" && (
                          <>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <FormField
                                control={perfilForm.control}
                                name="razaoSocial"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Razão Social</FormLabel>
                                    <FormControl>
                                      <Input placeholder="Digite a razão social" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={perfilForm.control}
                                name="nomeFantasia"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Nome Fantasia</FormLabel>
                                    <FormControl>
                                      <Input placeholder="Digite o nome fantasia" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <FormField
                                control={perfilForm.control}
                                name="inscricaoEstadual"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Inscrição Estadual</FormLabel>
                                    <FormControl>
                                      <Input placeholder="Digite a inscrição estadual" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={perfilForm.control}
                                name="inscricaoMunicipal"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Inscrição Municipal</FormLabel>
                                    <FormControl>
                                      <Input placeholder="Digite a inscrição municipal" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={perfilForm.control}
                                name="cnae"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>CNAE</FormLabel>
                                    <FormControl>
                                      <Input placeholder="Digite o CNAE" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <FormField
                                control={perfilForm.control}
                                name="regimeTributario"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Regime Tributário</FormLabel>
                                    <Select 
                                      value={field.value} 
                                      onValueChange={field.onChange}
                                    >
                                      <SelectTrigger>
                                        <SelectValue placeholder="Selecione o regime tributário" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="mei">MEI</SelectItem>
                                        <SelectItem value="simples">Simples Nacional</SelectItem>
                                        <SelectItem value="lucro_presumido">Lucro Presumido</SelectItem>
                                        <SelectItem value="lucro_real">Lucro Real</SelectItem>
                                      </SelectContent>
                                    </Select>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={perfilForm.control}
                                name="atividadePrincipal"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Atividade Principal</FormLabel>
                                    <FormControl>
                                      <Input placeholder="Digite a atividade principal" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          </>
                        )}

                        <Separator className="my-4" />
                        <h3 className="text-lg font-medium">Responsável</h3>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={perfilForm.control}
                            name="responsavelNome"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>
                                  Nome do Responsável <span className="text-red-500">*</span>
                                </FormLabel>
                                <FormControl>
                                  <Input placeholder="Digite o nome do responsável" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={perfilForm.control}
                            name="responsavelEmail"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>
                                  Email do Responsável <span className="text-red-500">*</span>
                                </FormLabel>
                                <FormControl>
                                  <Input placeholder="Digite o email do responsável" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={perfilForm.control}
                            name="responsavelTelefone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>
                                  Telefone do Responsável <span className="text-red-500">*</span>
                                </FormLabel>
                                <FormControl>
                                  <Input placeholder="Digite o telefone do responsável" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={perfilForm.control}
                            name="responsavelSetor"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Setor do Responsável</FormLabel>
                                <Select 
                                  value={field.value} 
                                  onValueChange={field.onChange}
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Selecione o setor" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Administrativa">Administrativa</SelectItem>
                                    <SelectItem value="Financeiro">Financeiro</SelectItem>
                                    <SelectItem value="Comercial">Comercial</SelectItem>
                                    <SelectItem value="Operacional">Operacional</SelectItem>
                                    <SelectItem value="TI">TI</SelectItem>
                                    <SelectItem value="RH">RH</SelectItem>
                                    <SelectItem value="Outro">Outro</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <Separator className="my-4" />
                        <h3 className="text-lg font-medium">Contador</h3>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField
                            control={perfilForm.control}
                            name="contadorNome"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Nome do Contador</FormLabel>
                                <FormControl>
                                  <Input placeholder="Digite o nome do contador" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={perfilForm.control}
                            name="contadorEmail"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email do Contador</FormLabel>
                                <FormControl>
                                  <Input placeholder="Digite o email do contador" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={perfilForm.control}
                            name="contadorTelefone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Telefone do Contador</FormLabel>
                                <FormControl>
                                  <Input placeholder="Digite o telefone do contador" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      <div className="flex justify-end gap-2">
                        <Button 
                          type="button"
                          variant="outline"
                          onClick={() => perfilForm.reset()}
                        >
                          Cancelar
                        </Button>
                        <Button 
                          type="submit"
                          className="bg-purple-600 hover:bg-purple-700"
                          disabled={updatePerfilMutation.isPending}
                        >
                          {updatePerfilMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Salvando...
                            </>
                          ) : (
                            <>
                              <Save className="mr-2 h-4 w-4" />
                              Salvar Alterações
                            </>
                          )}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Tab: Endereço / Contatos */}
            <TabsContent value="endereco" className="space-y-4">
              <Card className="shadow-sm">
                <CardContent className="pt-6">
                  <Form {...enderecoForm}>
                    <form onSubmit={enderecoForm.handleSubmit(handleSaveEndereco)} className="space-y-6">
                      <div className="space-y-4">
                          <Card className="shadow-sm">
                            <CardContent className="pt-6">
                              <h3 className="text-lg font-medium mb-4">Endereço</h3>
                            <div className="grid grid-cols-12 gap-4">
                            <div className="col-span-5">
                              <FormField
                                control={enderecoForm.control}
                                name="cidade"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Cidade:</FormLabel>
                                    <FormControl>
                                      <Input placeholder="Cidade" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                            <div className="col-span-4">
                              <FormField
                                control={enderecoForm.control}
                                name="bairro"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Bairro:</FormLabel>
                                    <FormControl>
                                      <Input placeholder="Bairro" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                            <div className="col-span-1">
                              <FormField
                                control={enderecoForm.control}
                                name="estado"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Estado:</FormLabel>
                                    <Select 
                                      value={field.value} 
                                      onValueChange={field.onChange}
                                    >
                                      <SelectTrigger>
                                        <SelectValue placeholder="UF" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="RS">RS</SelectItem>
                                        <SelectItem value="SP">SP</SelectItem>
                                        <SelectItem value="SC">SC</SelectItem>
                                        <SelectItem value="RJ">RJ</SelectItem>
                                        <SelectItem value="MG">MG</SelectItem>
                                        <SelectItem value="PR">PR</SelectItem>
                                        <SelectItem value="BA">BA</SelectItem>
                                        <SelectItem value="DF">DF</SelectItem>
                                        <SelectItem value="GO">GO</SelectItem>
                                        <SelectItem value="ES">ES</SelectItem>
                                        <SelectItem value="PE">PE</SelectItem>
                                        <SelectItem value="CE">CE</SelectItem>
                                        <SelectItem value="PA">PA</SelectItem>
                                        <SelectItem value="MT">MT</SelectItem>
                                        <SelectItem value="MA">MA</SelectItem>
                                        <SelectItem value="MS">MS</SelectItem>
                                        <SelectItem value="PB">PB</SelectItem>
                                        <SelectItem value="PI">PI</SelectItem>
                                        <SelectItem value="RN">RN</SelectItem>
                                        <SelectItem value="AL">AL</SelectItem>
                                        <SelectItem value="RO">RO</SelectItem>
                                        <SelectItem value="AM">AM</SelectItem>
                                        <SelectItem value="SE">SE</SelectItem>
                                        <SelectItem value="TO">TO</SelectItem>
                                        <SelectItem value="AC">AC</SelectItem>
                                        <SelectItem value="AP">AP</SelectItem>
                                        <SelectItem value="RR">RR</SelectItem>
                                      </SelectContent>
                                    </Select>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                            <div className="col-span-2">
                              <FormField
                                control={enderecoForm.control}
                                name="cep"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>CEP:</FormLabel>
                                    <FormControl>
                                      <Input placeholder="00000-000" {...field} className="w-full" />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <FormField
                                control={enderecoForm.control}
                                name="logradouro"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Logradouro:</FormLabel>
                                    <FormControl>
                                      <Input placeholder="Rua, Avenida, etc" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <FormField
                                control={enderecoForm.control}
                                name="numero"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Número:</FormLabel>
                                    <FormControl>
                                      <Input placeholder="123" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={enderecoForm.control}
                                name="complemento"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Complemento:</FormLabel>
                                    <FormControl>
                                      <Input placeholder="Complemento" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          </div>
                        </CardContent>
                          </Card>

                          <Card className="shadow-sm">
                            <CardContent className="pt-6">
                              <h3 className="text-lg font-medium mb-4">Contatos</h3>
                            <div className="space-y-6">
                              <div>
                                <h4 className="font-medium mb-4">Adicionar Novo Contato</h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                  <FormField
                                    control={enderecoForm.control}
                                    name="contatoNome"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Nome do Contato: <span className="text-red-500">*</span></FormLabel>
                                        <FormControl>
                                          <Input placeholder="Nome completo" {...field} required />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  <FormField
                                    control={enderecoForm.control}
                                    name="contatoSetor"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Setor Responsável:</FormLabel>
                                        <Select
                                          value={field.value}
                                          onValueChange={field.onChange}
                                        >
                                          <SelectTrigger>
                                            <SelectValue placeholder="Selecione o setor" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="comercial">Comercial</SelectItem>
                                            <SelectItem value="financeiro">Financeiro</SelectItem>
                                            <SelectItem value="operacional">Operacional</SelectItem>
                                            <SelectItem value="administrativo">Administrativo</SelectItem>
                                            <SelectItem value="outro">Outro</SelectItem>
                                          </SelectContent>
                                        </Select>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                                  <FormField
                                    control={enderecoForm.control}
                                    name="telefone"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Telefone: <span className="text-red-500">*</span></FormLabel>
                                        <FormControl>
                                          <Input placeholder="(00) 0000-0000" {...field} required />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  <FormField
                                    control={enderecoForm.control}
                                    name="email"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Email: <span className="text-red-500">*</span></FormLabel>
                                        <FormControl>
                                          <Input placeholder="email@exemplo.com" {...field} required />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  <FormField
                                    control={enderecoForm.control}
                                    name="whatsapp"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>WhatsApp:</FormLabel>
                                        <FormControl>
                                          <Input placeholder="(00) 00000-0000" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                </div>

                                <div className="flex justify-end gap-2">
                                  <Button 
                                    type="button"
                                    variant="outline"
                                    onClick={() => enderecoForm.reset()}
                                  >
                                    Cancelar
                                  </Button>
                                  <Button 
                                    type="submit"
                                    className="bg-purple-600 hover:bg-purple-700"
                                  >
                                    <Save className="mr-2 h-4 w-4" />
                                    Salvar Contato
                                  </Button>
                                </div>
                              </div>

                              <h3 className="text-lg font-medium mb-4">Lista de Contatos</h3>
                              <div className="border rounded-lg p-4">
                                <table className="w-full">
                                  <thead>
                                    <tr className="border-b">
                                      <th className="text-left py-2">Nome</th>
                                      <th className="text-left py-2">Setor</th>
                                      <th className="text-left py-2">Telefone</th>
                                      <th className="text-left py-2">Email</th>
                                      <th className="text-left py-2">WhatsApp</th>
                                      <th className="text-center py-2">Ações</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr className="border-b">
                                      <td className="py-2">João Silva</td>
                                      <td className="py-2">Comercial</td>
                                      <td className="py-2">(48) 99999-8888</td>
                                      <td className="py-2">joao@empresa.com</td>
                                      <td className="py-2">(48) 99999-8888</td>
                                      <td className="py-2 text-center">
                                        <Button variant="ghost" size="sm" className="text-blue-600">Editar</Button>
                                        <Button variant="ghost" size="sm" className="text-red-600">Excluir</Button>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>

                              {showAddContact && (
                                <div className="border rounded-lg p-4 bg-gray-50">
                                  <div className="flex justify-between items-center mb-4">
                                    <h4 className="font-medium">Adicionar Novo Contato</h4>
                                    <Button 
                                      variant="ghost" 
                                      size="sm"
                                      onClick={() => setShowAddContact(false)}
                                    >
                                      ×
                                    </Button>
                                  </div>

                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                    <FormField
                                      control={enderecoForm.control}
                                      name="contatoNome"
                                      render={({ field }) => (
                                        <FormItem>
                                          <FormLabel>Nome do Contato:</FormLabel>
                                          <FormControl>
                                            <Input placeholder="Nome completo" {...field} />
                                          </FormControl>
                                          <FormMessage />
                                        </FormItem>
                                      )}
                                    />
                                    <FormField
                                      control={enderecoForm.control}
                                      name="contatoSetor"
                                      render={({ field }) => (
                                        <FormItem>
                                          <FormLabel>Setor Responsável:</FormLabel>
                                          <Select
                                            value={field.value}
                                            onValueChange={field.onChange}
                                          >
                                            <SelectTrigger>
                                              <SelectValue placeholder="Selecione o setor" />
                                            </SelectTrigger>
                                            <SelectContent>
                                              <SelectItem value="comercial">Comercial</SelectItem>
                                              <SelectItem value="financeiro">Financeiro</SelectItem>
                                              <SelectItem value="operacional">Operacional</SelectItem>
                                              <SelectItem value="administrativo">Administrativo</SelectItem>
                                              <SelectItem value="outro">Outro</SelectItem>
                                            </SelectContent>
                                          </Select>
                                          <FormMessage />
                                        </FormItem>
                                      )}
                                    />
                                  </div>

                                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                                    <FormField
                                      control={enderecoForm.control}
                                      name="telefone"
                                      render={({ field }) => (
                                        <FormItem>
                                          <FormLabel>Telefone:</FormLabel>
                                          <FormControl>
                                            <Input placeholder="(00) 0000-0000" {...field} />
                                          </FormControl>
                                          <FormMessage />
                                        </FormItem>
                                      )}
                                    />
                                    <FormField
                                      control={enderecoForm.control}
                                      name="email"
                                      render={({ field }) => (
                                        <FormItem>
                                          <FormLabel>Email:</FormLabel>
                                          <FormControl>
                                            <Input placeholder="email@exemplo.com" {...field} />
                                          </FormControl>
                                          <FormMessage />
                                        </FormItem>
                                      )}
                                    />
                                    <FormField
                                      control={enderecoForm.control}
                                      name="whatsapp"
                                      render={({ field }) => (
                                        <FormItem>
                                          <FormLabel>WhatsApp:</FormLabel>
                                          <FormControl>
                                            <Input placeholder="(00) 00000-0000" {...field} />
                                          </FormControl>
                                          <FormMessage />
                                        </FormItem>
                                      )}
                                    />
                                  </div>

                                  <div className="flex justify-end gap-2">
                                    <Button
                                      variant="outline"
                                      onClick={() => setShowAddContact(false)}
                                    >
                                      Cancelar
                                    </Button>
                                    <Button
                                      className="bg-purple-600 hover:bg-purple-700"
                                    >
                                      Salvar Contato
                                    </Button>
                                  </div>
                                </div>
                              )}
                            </div>
                        </CardContent>
                          </Card>
                      </div>

                      <div className="flex justify-end">
                        <Button 
                          type="button"
                          variant="outline"
                          onClick={() => enderecoForm.reset()}
                          className="mr-2"
                        >
                          Cancelar
                        </Button>
                        <Button 
                          type="submit"
                          className="bg-purple-600 hover:bg-purple-700"
                          disabled={updateEnderecoMutation.isPending}
                        >
                          {updateEnderecoMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Salvando...
                            </>
                          ) : (
                            <>
                              <Save className="mr-2 h-4 w-4" />
                              Salvar Alterações
                            </>
                          )}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Tab: Usuários */}
            <TabsContent value="usuarios" className="space-y-4">
              <Card className="shadow-sm">
                <CardContent className="pt-6">
                  <div className="space-y-6">
                    {/* Adicionar/Editar Usuário */}
                    <div className="border p-4 rounded-lg">
                      <h3 className="text-lg font-medium mb-4">Adicionar / Editar Usuário</h3>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <Label htmlFor="user-name">Nome completo:</Label>
                          <Input id="user-name" placeholder="Nome Completo" />
                        </div>
                        <div>
                          <Label htmlFor="user-cpf">CPF:</Label>
                          <Input id="user-cpf" placeholder="000.000.000-00" />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <Label htmlFor="user-email">Email:</Label>
                          <Input id="user-email" placeholder="usuario@exemplo.com" />
                        </div>
                        <div>
                          <Label htmlFor="user-telefone">Telefone:</Label>
                          <Input id="user-telefone" placeholder="(00) 00000-0000" />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <Label htmlFor="user-username">Nome de usuário:</Label>
                          <Input id="user-username" placeholder="nome.usuario" />
                        </div>
                        <div>
                          <Label htmlFor="user-status">Status:</Label>
                          <Select defaultValue="ativo">
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione o status" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="ativo">Ativo</SelectItem>
                              <SelectItem value="inativo">Inativo</SelectItem>
                              <SelectItem value="bloqueado">Bloqueado</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="mb-4">
                        <Label className="mb-2 block">Permissões de acesso:</Label>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 p-3 border rounded-md">
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="perm-vendas" className="rounded border-gray-300" />
                            <label htmlFor="perm-vendas" className="text-sm">Vendas</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="perm-financeiro" className="rounded border-gray-300" />
                            <label htmlFor="perm-financeiro" className="text-sm">Financeiro</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="perm-produtos" className="rounded border-gray-300" />
                            <label htmlFor="perm-produtos" className="text-sm">Produtos</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="perm-relatorios" className="rounded border-gray-300" />
                            <label htmlFor="perm-relatorios" className="text-sm">Relatórios</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="perm-usuarios" className="rounded border-gray-300" />
                            <label htmlFor="perm-usuarios" className="text-sm">Usuários</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="perm-configuracoes" className="rounded border-gray-300" />
                            <label htmlFor="perm-configuracoes" className="text-sm">Configurações</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="perm-admin" className="rounded border-gray-300" />
                            <label htmlFor="perm-admin" className="text-sm">Administrador</label>
                          </div>
                        </div>
                      </div>

                      <div className="flex justify-end gap-2">
                        <Button variant="outline" className="mr-2">Cancelar</Button>
                        <Button className="bg-purple-600 hover:bg-purple-700">Salvar Alterações</Button>
                      </div>
                    </div>

                    {/* Redefiniçao de Senha */}
                    <div className="border p-4 rounded-lg">
                      <h3 className="text-lg font-medium mb-4">Redefinição de Senha</h3>
                      <div className="mb-4">
                        <p className="text-sm text-gray-500 mb-4">
                          Envie um email para o usuário para que ele possa redefinir sua senha.
                          O usuário receberá um link de recuperação válido por 24 horas.
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="md:col-span-2">
                            <Input 
                              id="reset-email" 
                              placeholder="Email do usuário" 
                              defaultValue="willianstrong@gmail.com" 
                            />
                          </div>
                          <div>
                            <Button 
                              className="w-full bg-purple-600 hover:bg-purple-700"
                              onClick={() => {
                                const email = (document.getElementById('reset-email') as HTMLInputElement).value;
                                if (!email) {
                                  toast({
                                    title: "Erro",
                                    description: "Informe o email do usuário",
                                    variant: "destructive"
                                  });
                                  return;
                                }

                                // Enviar solicitação para API
                                fetch('/api/auth/reset-password-request', {
                                  method: 'POST',
                                  headers: {
                                    'Content-Type': 'application/json',
                                  },
                                  body: JSON.stringify({ email }),
                                })
                                .then(response => response.json())
                                .then(data => {
                                  toast({
                                    title: "Sucesso",
                                    description: data.message || "Email de recuperação enviado com sucesso",
                                  });
                                })
                                .catch(error => {
                                  console.error('Erro ao enviar email:', error);
                                  toast({
                                    title: "Erro",
                                    description: "Erro ao enviar email de recuperação",
                                    variant: "destructive"
                                  });
                                });
                              }}
                            >
                              Enviar email de recuperação
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Usuários Cadastrados */}
                    <div>
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-medium">Usuários Cadastrados</h3>
                        <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                          <span className="mr-1">+</span> Novo Usuário
                        </Button>
                      </div>
                      <div className="overflow-auto">
                        <table className="min-w-full border-collapse">
                          <thead>
                            <tr className="bg-gray-50 border-b">
                              <th className="text-left py-2 px-4 font-medium text-gray-900">Nome</th>
                              <th className="text-left py-2 px-4 font-medium text-gray-900">Email</th>
                              <th className="text-left py-2 px-4 font-medium text-gray-900">Usuário</th>
                              <th className="text-left py-2 px-4 font-medium text-gray-900">Telefone</th>
                              <th className="text-left py-2 px-4 font-medium text-gray-900">Status</th>
                              <th className="text-center py-2 px-4 font-medium text-gray-900">Ações</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-b">
                              <td className="py-2 px-4">Willian Moreira Armstrong</td>
                              <td className="py-2 px-4">willianstrong@gmail.com</td>
                              <td className="py-2 px-4">wstrong</td>
                              <td className="py-2 px-4">(48) 99999-8888</td>
                              <td className="py-2 px-4">
                                <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                                  Ativo
                                </span>
                              </td>
                              <td className="py-2 px-4 text-center">
                                <div className="flex justify-center gap-2">
                                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-blue-600" title="Editar">
                                    <Edit3 className="h-4 w-4" />
                                  </Button>
                                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-orange-600" title="Resetar senha">
                                    <i className="h-4 w-4">🔑</i>
                                  </Button>
                                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-red-600" title="Excluir">
                                    <i className="h-4 w-4">×</i>
                                  </Button>
                                </div>
                              </td>
                            </tr>
                            <tr className="border-b">
                              <td className="py-2 px-4">Ana Silva Pereira</td>
                              <td className="py-2 px-4">ana.silva@exemplo.com</td>
                              <td className="py-2 px-4">anasilva</td>
                              <td className="py-2 px-4">(11) 97777-6666</td>
                              <td className="py-2 px-4">
                                <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                                  Ativo
                                </span>
                              </td>
                              <td className="py-2 px-4 text-center">
                                <div className="flex justify-center gap-2">
                                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-blue-600" title="Editar">
                                    <Edit3 className="h-4 w-4" />
                                  </Button>
                                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-orange-600" title="Resetar senha">
                                    <i className="h-4 w-4">🔑</i>
                                  </Button>
                                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-red-600" title="Excluir">
                                    <i className="h-4 w-4">×</i>
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div className="mt-4 flex justify-between items-center">
                        <div className="text-sm text-gray-500">
                          Mostrando 1-2 de 2 registros
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm" disabled>Prev</Button>
                          <div className="flex items-center">
                            <Button variant="outline" size="sm" className="rounded-full bg-purple-600 text-white border-purple-600">1</Button>
                          </div>
                          <Button variant="outline" size="sm" disabled>Next</Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Tab: Financeiro */}
            <TabsContent value="financeiro" className="space-y-4">
              <Card className="shadow-sm">
                <CardContent className="pt-6">
                  <div className="space-y-6">
                    {/* Plano Atual */}
                    <div className="border p-4 rounded-lg">
                      <h3 className="text-lg font-medium mb-4">Seu Plano Atual</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                        <div className="bg-white rounded-lg border border-purple-200 p-5 shadow-sm">
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <span className="bg-purple-100 text-purple-800 text-xs font-semibold px-2.5 py-0.5 rounded">
                                Plano Atual
                              </span>
                              <h3 className="text-xl font-bold mt-2">Plano Basic</h3>
                            </div>
                            <div className="text-right">
                              <span className="text-sm text-gray-500">Valor mensal</span>
                              <p className="text-2xl font-bold text-gray-900">R$ 29,90</p>
                            </div>
                          </div>
                          <div className="mb-4 pb-4 border-b">
                            <div className="flex items-center mb-2">
                              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                              <span className="text-sm">Até 5 usuários</span>
                            </div>
                            <div className="flex items-center mb-2">
                              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                              <span className="text-sm">Acesso básico às ferramentas</span>
                            </div>
                            <div className="flex items-center">
                              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                              <span className="text-sm">Suporte por email</span>
                            </div>
                          </div>
                          <div className="text-center">
                            <div className="mb-2 text-sm font-semibold text-purple-600">Próximo vencimento: 27/05/2025</div>
                            <Button className="w-full bg-purple-600 hover:bg-purple-700">
                              Fazer Upgrade de Plano
                            </Button>
                          </div>
                        </div>

                        <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-lg border border-purple-200 p-5 shadow-sm flex flex-col h-full">
                          <h4 className="font-semibold text-purple-800 mb-3 text-center">Conheça nossos outros planos</h4>
                          <div className="space-y-3 flex-grow">
                            <div className="flex items-center justify-between p-2 rounded-md bg-white border border-purple-100 hover:shadow-sm transition-all">
                              <div className="flex items-center">
                                <Badge className="bg-purple-100 text-purple-800 mr-2">Popular</Badge>
                                <span className="font-medium">Premium</span>
                              </div>
                              <span className="font-bold text-purple-800">R$ 59,90/mês</span>
                            </div>
                            <div className="flex items-center justify-between p-2 rounded-md bg-white border border-purple-100 hover:shadow-sm transition-all">
                              <div className="flex items-center">
                                <Badge className="bg-indigo-100 text-indigo-800 mr-2">Empresarial</Badge>
                                <span className="font-medium">Enterprise</span>
                              </div>
                              <span className="font-bold text-purple-800">R$ 99,90/mês</span>
                            </div>
                            <div className="mt-4 text-center">
                              <Button variant="outline" className="w-full border-purple-200 text-purple-700 hover:bg-purple-50">
                                Ver todos os planos
                              </Button>
                            </div>
                          </div>
                        </div>

                        <div className="bg-green-50 rounded-lg border border-green-200 p-5 shadow-sm flex flex-col h-full">
                          <h4 className="text-green-800 font-semibold mb-2">Fatura Pendente</h4>
                          <div className="space-y-2 flex-grow">
                            <div className="flex justify-between">
                              <span className="text-sm text-gray-600">ID da Fatura:</span>
                              <span className="font-medium">F-2023785</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-gray-600">Vencimento:</span>
                              <span className="font-medium">27/04/2025</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-gray-600">Valor:</span>
                              <span className="font-medium">R$ 29,90</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-gray-600">Status:</span>
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium bg-yellow-100 text-yellow-800">
                                Pendente
                              </span>
                            </div>
                          </div>
                          <Button className="w-full bg-green-600 hover:bg-green-700 text-white mt-auto">
                            Pagar Agora
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Gerenciar Cartões */}
                    <div className="border p-4 rounded-lg">
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-medium">Formas de Pagamento</h3>
                        <Button 
                          size="sm" 
                          className="bg-purple-600 hover:bg-purple-700"
                          onClick={() => setShowAddCard(true)}
                        >
                          + Adicionar Cartão
                        </Button>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 border rounded-lg bg-gray-50">
                          <div className="flex items-center">
                            <div className="bg-blue-600 text-white rounded p-2 mr-3">
                              <CreditCardIcon className="h-5 w-5" />
                            </div>
                            <div>
                              <p className="font-medium">Cartão de Crédito</p>
                              <p className="text-sm text-gray-500">**** **** **** 4589 | Vence em 09/27</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Padrão</Badge>
                            <div className="flex">
                              <Button size="sm" variant="ghost" className="text-blue-600 h-8">
                                Editar
                              </Button>
                              <Button size="sm" variant="ghost" className="text-red-600 h-8">
                                Remover
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Form para adicionar cartão - mostrado apenas quando showAddCard = true */}
                      {showAddCard && (
                        <div className="mt-6 border p-4 rounded-lg bg-gray-50">
                          <h4 className="text-base font-medium mb-4">Adicionar Novo Cartão</h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                              <Label htmlFor="card-number">Número do cartão:</Label>
                              <Input id="card-number" placeholder="0000 0000 0000 0000" />
                            </div>
                            <div>
                              <Label htmlFor="card-name">Nome no Cartão:</Label>
                              <Input id="card-name" placeholder="Nome no Cartão" />
                            </div>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                              <Label htmlFor="card-validity">Vencimento:</Label>
                              <Input id="card-validity" placeholder="MM/AA" />
                            </div>
                            <div>
                              <Label htmlFor="card-cvv">CVV:</Label>
                              <Input id="card-cvv" placeholder="CVV" />
                            </div>
                          </div>
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="outline" 
                              className="mr-2"
                              onClick={() => setShowAddCard(false)}
                            >
                              Cancelar
                            </Button>
                            <Button 
                              className="bg-purple-600 hover:bg-purple-700"
                              onClick={() => {
                                toast({
                                  title: "Cartão adicionado",
                                  description: "Seu cartão foi adicionado com sucesso",
                                  variant: "default",
                                });
                                setShowAddCard(false);
                              }}
                            >
                              Adicionar Cartão
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Pagamentos */}
                    <div>
                      <h3 className="text-lg font-medium mb-4">Pagamentos</h3>
                      <div className="overflow-auto">
                        <table className="min-w-full border-collapse">
                          <thead>
                            <tr className="bg-gray-50 border-b">
                              <th className="text-left py-2 px-4 font-medium text-gray-900">ID</th>
                              <th className="text-left py-2 px-4 font-medium text-gray-900">Status</th>
                              <th className="text-left py-2 px-4 font-medium text-gray-900">Vencimento</th>
                              <th className="text-left py-2 px-4 font-medium text-gray-900">Plano Atual</th>
                              <th className="text-center py-2 px-4 font-medium text-gray-900">Comprovante</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-b">
                              <td className="py-2 px-4">202285-01</td>
                              <td className="py-2 px-4">
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                  Pago
                                </span>
                              </td>
                              <td className="py-2 px-4">27-10-2022</td>
                              <td className="py-2 px-4">Basic</td>
                              <td className="py-2 px-4 text-center">
                                <Button size="sm" variant="ghost" className="h-8 text-white bg-green-500 hover:bg-green-600">
                                  Download
                                </Button>
                              </td>
                            </tr>
                            <tr className="border-b">
                              <td className="py-2 px-4">202285-02</td>
                              <td className="py-2 px-4">
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                  Pago
                                </span>
                              </td>
                              <td className="py-2 px-4">28-10-2022</td>
                              <td className="py-2 px-4">Basic</td>
                              <td className="py-2 px-4 text-center">
                                <Button size="sm" variant="ghost" className="h-8 text-white bg-green-500 hover:bg-green-600">
                                  Download
                                </Button>
                              </td>
                            </tr>
                            <tr className="border-b">
                              <td className="py-2 px-4">202285-03</td>
                              <td className="py-2 px-4">
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                  Pago
                                </span>
                              </td>
                              <td className="py-2 px-4">27-10-2022</td>
                              <td className="py-2 px-4">Basic</td>
                              <td className="py-2 px-4 text-center">
                                <Button size="sm" variant="ghost" className="h-8 text-white bg-green-500 hover:bg-green-600">
                                  Download
                                </Button>
                              </td>
                            </tr>
                            <tr className="border-b">
                              <td className="py-2 px-4">202285-04</td>
                              <td className="py-2 px-4">
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                  Pago
                                </span>
                              </td>
                              <td className="py-2 px-4">28-10-2022</td>
                              <td className="py-2 px-4">Basic</td>
                              <td className="py-2 px-4 text-center">
                                <Button size="sm" variant="ghost" className="h-8 text-white bg-green-500 hover:bg-green-600">
                                  Download
                                </Button>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div className="mt-4 flex justify-between items-center">
                        <div className="text-sm text-gray-500">
                          Mostrando 5 pagamentos  →  
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">Prev</Button>
                          <div className="flex items-center">
                            <Button variant="outline" size="sm" className="rounded-full bg-purple-600 text-white border-purple-600">1</Button>
                          </div>
                          <Button variant="outline" size="sm">Next</Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Tab: Segurança */}
            <TabsContent value="seguranca" className="space-y-4">
              <Card className="shadow-sm">
                <CardContent className="pt-6">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-2">Verificação em duas etapas</h3>
                      <p className="text-sm text-gray-500 mb-4">
                        Para maior segurança, configure seu acesso em mais de um método.
                      </p>

                      {/* Autenticação */}
                      <div className="border p-4 rounded-lg mb-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center">
                            <div className="h-6 w-6 rounded-full bg-purple-100 flex items-center justify-center mr-2">
                              <span className="h-3 w-3 rounded-full bg-purple-600"></span>
                            </div>
                            <Label>Autenticação</Label>
                          </div>
                          <div className="h-6 w-12 relative rounded-full bg-purple-200">
                            <div className="absolute top-1 left-1 h-4 w-4 rounded-full bg-purple-600"></div>
                          </div>
                        </div>
                        <div className="flex gap-2 mb-4">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="rounded-md"
                            onClick={() => {
                              setShowPasswordSection(!showPasswordSection);
                              setShow2FASection(false);
                            }}
                          >
                            Senha
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="rounded-md bg-purple-100 text-purple-600 border-purple-200"
                            onClick={() => {
                              setShow2FASection(!show2FASection);
                              setShowPasswordSection(false);
                            }}
                          >
                            2FA
                          </Button>
                        </div>

                        {/* 2FA Configuration Section */}
                        {show2FASection && (
                          <div className="space-y-4">
                            <h4 className="font-medium mb-2">Configurar Autenticação em Dois Fatores</h4>
                            <div className="space-y-4">
                              <div className="flex flex-col items-center justify-center">
                                <Label className="text-center w-full mb-2">Código QR</Label>
                                <div className="w-48 h-48 bg-gray-100 flex items-center justify-center border rounded-lg mb-2 relative overflow-hidden">
                                  <div className="absolute inset-0 flex items-center justify-center">
                                    <div className="w-36 h-36 bg-white">
                                      <div className="w-full h-full border-2 border-purple-600 relative">
                                        <div key={Math.floor(Date.now() / 1000)} className="absolute inset-2 grid grid-cols-6 grid-rows-6 gap-1">
                                          {Array.from({ length: 36 }).map((_, i) => {
                                            const positionPattern = (i % 3 === 0 || i < 3 || i > 32 || i % 6 === 0);
                                            const dynamicRandom = Math.sin(Date.now() / 1000 + i) * 0.5 + 0.5;
                                            return (
                                              <div
                                                key={i}
                                                className={`bg-purple-600 ${
                                                  positionPattern || dynamicRandom > 0.5 ? "opacity-100" : "opacity-0"
                                                } transition-opacity duration-300`}
                                              />
                                            );
                                          })}
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <CountdownTimer />
                              </div>
                              <div>
                                <Label htmlFor="verification-code">Código de Verificação</Label>
                                <Input id="verification-code" placeholder="Digite o código do seu aplicativo" />
                              </div>
                              <div className="flex justify-end gap-2">
                                <Button variant="outline">Cancelar</Button>
                                <Button className="bg-purple-600 hover:bg-purple-700">Ativar 2FA</Button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Definir nova senha */}
                        {showPasswordSection && (
                          <div className="space-y-4">
                            <h4 className="font-medium mb-2">Definir nova senha</h4>
                            <div className="space-y-4">
                              <div>
                                <Label htmlFor="current-password">Senha atual</Label>
                                <Input id="current-password" type="password" placeholder="********" />
                              </div>
                              <div>
                                <Label htmlFor="new-password">Nova senha</Label>
                                <Input id="new-password" type="password" placeholder="Nova senha" />
                              </div>
                              <div>
                                <Label htmlFor="confirm-password">Confirme sua senha</Label>
                                <Input id="confirm-password" type="password" placeholder="Confirme sua senha" />
                              </div>
                              <div className="flex justify-end gap-2">
                                <Button variant="outline">Cancelar</Button>
                                <Button className="bg-purple-600 hover:bg-purple-700">Salvar Alterações</Button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Email de recuperação */}
                      <div className="border p-4 rounded-lg mb-6">
                        <h4 className="font-medium mb-2">Email de recuperação</h4>
                        <p className="text-sm text-gray-500 mb-2">
                          Este email já está sendo usado para notificações e para o processo de recuperação.
                        </p>
                        <div className="flex items-center gap-2">
                          <Input defaultValue="me********@gmail.com" disabled className="bg-gray-50" />
                        </div>
                      </div>

                      {/* Recuperação por SMS */}
                      <div className="border p-4 rounded-lg mb-6">
                        <h4 className="font-medium mb-2">Recuperação por SMS</h4>
                        <p className="text-sm text-gray-500 mb-2">
                          Um código será enviado para o SMS caso não se lembre da sua senha.
                        </p>
                        <div className="flex items-center gap-2">
                          <Input defaultValue="+55 (00) 00000-0000" className="flex-1" />
                          <Button className="bg-purple-600 hover:bg-purple-700">Verificar</Button>
                        </div>
                      </div>
                    </div>

                    {/* Dispositivos Registrados */}
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-medium">Dispositivos Registrados</h3>
                        <div className="h-6 w-12 relative rounded-full bg-purple-200">
                          <div className="absolute top-1 left-1 h-4 w-4 rounded-full bg-purple-600"></div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        {/* Dispositivo 1 */}
                        <div className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-gray-100 rounded">
                              <div className="h-6 w-6 text-gray-500">📱</div>
                            </div>
                            <div>
                              <div className="font-medium">Mobile LG-0025</div>
                              <div className="text-xs text-gray-500">Registro: Out 22, 21:45</div>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm" className="text-gray-500">×</Button>
                        </div>

                        {/* Dispositivo 2 */}
                        <div className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-gray-100 rounded">
                              <div className="h-6 w-6 text-gray-500">💻</div>
                            </div>
                            <div>
                              <div className="font-medium">Lenovo-09R553</div>
                              <div className="text-xs text-gray-500">Registro: Out 22, 21:34</div>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm" className="text-gray-500">×</Button>
                        </div>

                        {/* Dispositivo 3 */}
                        <div className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-gray-100 rounded">
                              <div className="h-6 w-6 text-gray-500">🖥️</div>
                            </div>
                            <div>
                              <div className="font-medium">MackBook-Studio</div>
                              <div className="text-xs text-gray-500">Registro: Set 22, 21:47</div>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm" className="text-gray-500">×</Button>
                        </div>

                        {/* Dispositivo 4 */}
                        <div className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-gray-100 rounded">
                              <div className="h-6 w-6 text-gray-500">🖱️</div>
                            </div>
                            <div>
                              <div className="font-medium">Apple-Desktop</div>
                              <div className="text-xs text-gray-500">Registro: Set 22, 15:47</div>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm" className="text-gray-500">×</Button>
                        </div>
                      </div>
                    </div>


                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}