import React from 'react';
import ReactLandingPage from './index';

// Este componente agora apenas renderiza nossa implementação React da landing page
export default function LandingPage() {
  return <ReactLandingPage />;
}