import { useState, useEffect } from "react";
import LogoImage from "@/assets/images/logo/negativoo.png";

export default function SplashScreen() {
  // Removido o efeito de fade out para que a tela de splash permaneça 
  // até que as imagens sejam carregadas na tela principal

  return (
    <div 
      className="fixed inset-0 flex items-center justify-center z-50 overflow-hidden"
    >      
      {/* Fundo quase transparente */}
      <div className="absolute inset-0 bg-white bg-opacity-95"></div>
      
      {/* Conteúdo - Logo e frase como um elemento único com animação */}
      <div className="relative z-10 flex flex-col items-center justify-center animate-pulse">
        {/* Apenas o logo */}
        <div className="flex items-center justify-center">
          <img src={LogoImage} alt="Meu Preço Certo" className="h-40" />
        </div>
      </div>
    </div>
  );
}
