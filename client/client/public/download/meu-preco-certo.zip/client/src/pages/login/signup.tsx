import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Building, Eye, EyeOff, Loader2, ArrowLeft, ChevronRight, Check, ShieldCheck, BarChart2, Users, LineChart, Briefcase, ArrowUp, TrendingUp, Clock, X } from "lucide-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import LogoDesktop from "@/assets/images/logo/Negativo.png";
import LogoMobile from "@/assets/images/logo/principal.png";

// Schema de validação para cadastro
const signupSchema = z.object({
  username: z.string().min(3, { message: "Nome de usuário deve ter pelo menos 3 caracteres" }),
  email: z.string().email({ message: "Por favor, insira um endereço de e-mail válido" }),
  password: z.string()
    .min(8, "Digite uma senha forte com no mínimo 8 caracteres")
    .regex(/[A-Z]/, "A senha deve conter pelo menos uma letra maiúscula")
    .regex(/[a-z]/, "A senha deve conter letras minúsculas")
    .regex(/[0-9]/, "A senha deve conter números")
    .regex(/[^A-Za-z0-9]/, "A senha deve conter caracteres especiais (!@#$%^&*)"),
  confirmPassword: z.string(),
  terms: z.boolean().refine(val => val === true, {
    message: "Você precisa aceitar os termos para continuar"
  })
}).refine((data) => data.password === data.confirmPassword, {
  message: "As senhas não coincidem",
  path: ["confirmPassword"],
});

type SignupFormValues = z.infer<typeof signupSchema>;

export default function SignupPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [termsModalOpen, setTermsModalOpen] = useState(false);
  const [privacyModalOpen, setPrivacyModalOpen] = useState(false);
  const [precificacoes, setPrecificacoes] = useState([
    { name: "Processador i7", value: "R$ 2.349", change: "+5%" },
    { name: "Reparo Notebook", value: "R$ 159", change: "-2%" },
    { name: "Aluguel Projetor", value: "R$ 89/dia", change: "+8%" },
    { name: "Memória RAM", value: "R$ 345", change: "+12%" },
    { name: "Pizza Margherita", value: "R$ 45", change: "+7%" },
    { name: "Hambúrguer Artesanal", value: "R$ 32", change: "+4%" },
    { name: "Açaí 500ml", value: "R$ 18", change: "+2%" },
    { name: "Combo Sushi", value: "R$ 89", change: "+3%" },
    { name: "Refrigerante 2L", value: "R$ 8", change: "+1%" },
    { name: "Pudim", value: "R$ 15", change: "+6%" },
    { name: "X-Tudo", value: "R$ 27", change: "+5%" }
  ]);
  
  // Efeito para simular valores atualizando dinamicamente
  useEffect(() => {
    // Atualizar números do dashboard
    const dashboardInterval = setInterval(() => {
      // Simular atualizações do lucro atual
      const lucroEl = document.getElementById('lucro-atual');
      if (lucroEl) {
        const baseValue = 3452;
        const newValue = baseValue + Math.floor(Math.random() * 200) - 100;
        lucroEl.textContent = `R$ ${newValue.toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      }
      
      // Atualizar métricas
      const metrics = document.querySelectorAll('.metric-value');
      metrics.forEach(metric => {
        if (Math.random() > 0.7) {
          const el = metric as HTMLElement;
          const value = el.dataset.baseValue || '';
          const newVal = parseFloat(value) + (Math.random() * 2 - 1);
          el.textContent = el.dataset.format?.replace('{value}', newVal.toFixed(1)) || '';
        }
      });
    }, 3000);
    
    // Animar o gráfico de estoque
    const chartInterval = setInterval(() => {
      const stockValues = document.querySelectorAll('.stock-value');
      stockValues.forEach(value => {
        const randomHeight = Math.floor(20 + Math.random() * 60);
        (value as HTMLElement).style.height = `${randomHeight}%`;
      });
    }, 1000);
    
    // Novos produtos para simulação
    const novosProdutos = [
      { name: "Fonte ATX 600W", value: "R$ 399", change: "+3%" },
      { name: "Manutenção PC", value: "R$ 210", change: "+4%" },
      { name: "Aluguel Impressora", value: "R$ 120/dia", change: "-5%" },
      { name: "Teclado Mecânico", value: "R$ 289", change: "+7%" },
      { name: "Monitor 24\"", value: "R$ 799", change: "+2%" }
    ];
    
    const precificacoesInterval = setInterval(() => {
      if (Math.random() > 0.7) {
        const novoProduto = novosProdutos[Math.floor(Math.random() * novosProdutos.length)];
        setPrecificacoes(prev => {
          // Add ao início e remover o último para manter o mesmo número de itens
          const updated = [novoProduto, ...prev.slice(0, 3)];
          return updated;
        });
      }
    }, 5000);
    
    return () => {
      clearInterval(dashboardInterval);
      clearInterval(chartInterval);
      clearInterval(precificacoesInterval);
    };
  }, []);

  const form = useForm<SignupFormValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      terms: false
    }
  });

  async function onSubmit(data: SignupFormValues) {
    setIsLoading(true);

    try {
      // Em uma aplicação real, registraríamos o usuário no backend
      await new Promise(resolve => setTimeout(resolve, 1500));

      toast({
        title: "Conta criada",
        description: "Você criou sua conta com sucesso.",
      });

      // Redirecionar para a página de login após o cadastro bem-sucedido
      setLocation("/acessar");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Falha no cadastro",
        description: "Ocorreu um erro durante o cadastro. Por favor, tente novamente.",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-white flex flex-col md:flex-row">
      {/* Seção de apresentação - à esquerda */}
      <div className="hidden md:flex md:w-1/2 lg:w-3/5 xl:w-2/3 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-700 via-purple-600 to-blue-600"></div>
        <div className="absolute inset-0" style={{ 
          backgroundImage: "radial-gradient(circle at 25% 25%, rgba(255, 255, 255, 0.2) 0%, transparent 50%), radial-gradient(circle at 75% 75%, rgba(255, 255, 255, 0.15) 0%, transparent 45%)" 
        }}></div>
        <div className="absolute inset-0 opacity-20" style={{ 
          backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" 
        }}></div>
        
        <div className="relative w-full h-full z-10">
          <div className="w-full h-full flex flex-col justify-center items-center p-4 md:p-6 lg:p-8">
            {/* Logo e marca - versão desktop */}
            <div className="flex flex-col items-center mb-6">
              <img src={LogoDesktop} alt="Meu Preço Certo" className="h-20 mb-4" />
            </div>
            
            {/* Conteúdo central destacado */}
            <div className="max-w-xl">
              <div className="flex items-center justify-center mb-3">
                <div className="px-3 py-1 rounded-full bg-white/20 text-white text-sm font-medium backdrop-blur-sm">
                  O melhor preço começa com o preço certo
                </div>
              </div>
              
              <h2 className="text-2xl md:text-3xl font-bold text-center text-white mb-6">
                Maximize seus 
                <span className="bg-gradient-to-r from-yellow-300 to-amber-500 bg-clip-text text-transparent">
                  {" "}lucros com precisão
                </span>
              </h2>

              {/* Simulações de dashboard e gráficos */}
              {/* Conteúdo mantido para não quebrar a experiência, porém não mostrado aqui para brevidade */}
              
            </div>
          </div>
        </div>
      </div>

      {/* Seção de formulário - à direita */}
      <div className="w-full md:w-1/2 lg:w-2/5 xl:w-1/3 p-4 md:p-6 lg:p-8 flex flex-col justify-center bg-white">
        <div className="mx-auto w-full max-w-md">
          {/* Logo e cabeçalho (visível apenas em mobile) */}
          <div className="md:hidden text-center mb-6 mt-8">
            <img src={LogoMobile} alt="Meu Preço Certo" className="h-24 mx-auto mb-6" />
          </div>

          {/* Botão voltar */}
          <div className="h-[42px] flex items-start">
            <Button
              variant="ghost"
              className="px-0 text-gray-600 hover:text-gray-900 hover:bg-transparent"
              onClick={() => setLocation("/")}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar para a página inicial
            </Button>
          </div>

          {/* Título e subtítulo */}
          <div className="mb-8">
            <h2 className="text-3xl font-extrabold mb-3 text-gray-900">Crie sua conta</h2>
            <div className="text-gray-600">
              Cadastre-se para acessar todas as ferramentas de precificação.
            </div>
          </div>

          {/* Formulário de cadastro */}
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700 font-medium">Nome de usuário</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        className={`h-12 rounded-lg border-gray-300 focus:border-primary focus:ring focus:ring-primary/20 ${
                          form.formState.errors.username ? 'border-red-500 ring ring-red-200' : ''
                        }`}
                        placeholder="Seu nome de usuário"
                        autoComplete="username"
                        onBlur={(e) => {
                          field.onBlur();
                          // Validação adicional pode ser feita aqui se necessário
                        }}
                      />
                    </FormControl>
                    <FormMessage className="text-xs font-medium" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700 font-medium">E-mail</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        className={`h-12 rounded-lg border-gray-300 focus:border-primary focus:ring focus:ring-primary/20 ${
                          form.formState.errors.email ? 'border-red-500 ring ring-red-200' : ''
                        }`}
                        placeholder="seu@email.com"
                        autoComplete="email"
                        onBlur={(e) => {
                          field.onBlur();
                          // Validação adicional pode ser feita aqui se necessário
                        }}
                      />
                    </FormControl>
                    <FormMessage className="text-xs font-medium" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700 font-medium">Senha</FormLabel>
                    <div className="relative">
                      <FormControl>
                        <Input
                          {...field}
                          className={`h-12 rounded-lg border-gray-300 focus:border-primary focus:ring focus:ring-primary/20 ${
                            form.formState.errors.password ? 'border-red-500 ring ring-red-200' : ''
                          }`}
                          type={showPassword ? "text" : "password"}
                          placeholder="••••••••"
                          autoComplete="new-password"
                          onBlur={(e) => {
                            field.onBlur();
                            // Validação adicional pode ser feita aqui se necessário
                          }}
                        />
                      </FormControl>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 text-gray-400 hover:text-gray-700"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                    <FormMessage className="text-xs font-medium" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700 font-medium">Confirmar senha</FormLabel>
                    <div className="relative">
                      <FormControl>
                        <Input
                          {...field}
                          className={`h-12 rounded-lg border-gray-300 focus:border-primary focus:ring focus:ring-primary/20 ${
                            form.formState.errors.confirmPassword ? 'border-red-500 ring ring-red-200' : ''
                          }`}
                          type={showConfirmPassword ? "text" : "password"}
                          placeholder="••••••••"
                          autoComplete="new-password"
                          onBlur={(e) => {
                            field.onBlur();
                            // Validação adicional pode ser feita aqui se necessário
                          }}
                        />
                      </FormControl>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 text-gray-400 hover:text-gray-700"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                    <FormMessage className="text-xs font-medium" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="terms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 mt-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        className="data-[state=checked]:bg-primary"
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel className="text-sm font-normal">
                        Eu concordo com os{" "}
                        <Button 
                          type="button"
                          variant="link" 
                          className="p-0 text-primary font-medium h-auto"
                          onClick={(e) => {
                            e.preventDefault();
                            setTermsModalOpen(true);
                          }}
                        >
                          Termos de Serviço
                        </Button>{" "}
                        e{" "}
                        <Button 
                          type="button"
                          variant="link" 
                          className="p-0 text-primary font-medium h-auto"
                          onClick={(e) => {
                            e.preventDefault();
                            setPrivacyModalOpen(true);
                          }}
                        >
                          Política de Privacidade
                        </Button>
                      </FormLabel>
                      <FormMessage className="text-xs font-medium" />
                    </div>
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full h-12 bg-primary hover:bg-primary/90 text-white font-semibold rounded-lg flex items-center justify-center group mt-4"
                disabled={isLoading}
              >
                {isLoading ? (
                  <span className="flex items-center">
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Criando conta...
                  </span>
                ) : (
                  <span className="flex items-center">
                    Criar conta
                    <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </span>
                )}
              </Button>
            </form>
          </Form>

          <div className="text-center mt-6">
            <p className="text-gray-600">
              Já possui uma conta?{" "}
              <Button
                variant="link"
                className="font-medium text-primary hover:text-primary/90 p-0 h-auto"
                onClick={() => setLocation("/acessar")}
              >
                Entrar
              </Button>
            </p>
          </div>

          {/* Rodapé */}
          <div className="mt-12 text-center text-gray-500 text-xs">
            <p>© {new Date().getFullYear()} Meu Preço Certo. Todos os direitos reservados.</p>
            <div className="mt-2">
              <button 
                type="button"
                className="mx-2 hover:text-gray-700 transition-colors bg-transparent border-none cursor-pointer text-gray-500 text-xs p-0"
                onClick={() => setPrivacyModalOpen(true)}
              >
                Política de Privacidade
              </button>
              <button 
                type="button"
                className="mx-2 hover:text-gray-700 transition-colors bg-transparent border-none cursor-pointer text-gray-500 text-xs p-0"
                onClick={() => setTermsModalOpen(true)}
              >
                Termos de Serviço
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Modal de Termos de Serviço */}
      <Dialog open={termsModalOpen} onOpenChange={setTermsModalOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold flex items-center">
              <ShieldCheck className="h-6 w-6 mr-2 text-primary" />
              Termos de Serviço
            </DialogTitle>
            <DialogDescription>
              Por favor, leia atentamente os nossos termos de serviço.
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="flex-1 pr-4 my-6">
            <div className="prose prose-gray max-w-none">
              <h3>1. Aceitação dos Termos</h3>
              <p>
                Ao acessar ou usar o serviço do Meu Preço Certo, você concorda em ficar vinculado a estes Termos de Serviço. Se você não concordar com algum aspecto destes termos, não poderá usar nosso serviço.
              </p>
              
              <h3>2. Descrição do Serviço</h3>
              <p>
                O Meu Preço Certo fornece ferramentas online para a precificação de produtos e serviços, análise de custos e otimização de margens de lucro. Nosso objetivo é ajudar empreendedores e empresas a estabelecerem preços competitivos e lucrativos para seus produtos e serviços.
              </p>
              
              <h3>3. Conta de Usuário</h3>
              <p>
                Para utilizar determinadas funcionalidades do serviço, você precisa criar uma conta. Você é responsável por manter a confidencialidade de suas credenciais de conta e por todas as atividades que ocorrem sob sua conta. Você concorda em notificar imediatamente o Meu Preço Certo sobre qualquer uso não autorizado de sua conta.
              </p>
              
              <h3>4. Uso do Serviço</h3>
              <p>
                Você concorda em usar o serviço apenas para fins legais e de acordo com estes Termos. Você não pode:
              </p>
              <ul>
                <li>Usar o serviço para qualquer propósito ilegal ou não autorizado</li>
                <li>Violar quaisquer leis em sua jurisdição (incluindo leis de direitos autorais)</li>
                <li>Interferir ou interromper a segurança ou funcionalidade do serviço</li>
                <li>Distribuir vírus ou qualquer outro código malicioso</li>
                <li>Tentar acessar áreas restritas do sistema</li>
              </ul>
              
              <h3>5. Conteúdo do Usuário</h3>
              <p>
                Ao enviar qualquer conteúdo para o serviço, você garante que tem o direito de fazer isso e concede ao Meu Preço Certo uma licença não exclusiva para usar, reproduzir e exibir esse conteúdo em conexão com o serviço.
              </p>
              
              <h3>6. Pagamentos e Assinaturas</h3>
              <p>
                Alguns recursos do serviço podem exigir pagamento. Ao se inscrever em um plano pago, você concorda em pagar todas as taxas associadas ao plano selecionado. As assinaturas serão renovadas automaticamente a menos que você cancele sua assinatura antes da data de renovação.
              </p>
              
              <h3>7. Cancelamento e Rescisão</h3>
              <p>
                Você pode cancelar sua conta a qualquer momento. O Meu Preço Certo reserva-se o direito de suspender ou encerrar sua conta a seu critério, sem aviso prévio, por violação destes Termos.
              </p>
              
              <h3>8. Limitação de Responsabilidade</h3>
              <p>
                Em nenhuma circunstância o Meu Preço Certo, seus diretores, funcionários ou agentes serão responsáveis por quaisquer danos indiretos, incidentais, especiais, consequentes ou punitivos.
              </p>
              
              <h3>9. Alterações nos Termos</h3>
              <p>
                O Meu Preço Certo reserva-se o direito de modificar estes Termos a qualquer momento. As alterações entrarão em vigor imediatamente após a publicação dos Termos atualizados. O uso continuado do serviço após tais alterações constitui sua aceitação dos novos Termos.
              </p>
              
              <h3>10. Lei Aplicável</h3>
              <p>
                Estes Termos serão regidos e interpretados de acordo com as leis do Brasil, sem considerar seus princípios de conflitos de leis.
              </p>
            </div>
          </ScrollArea>
          
          <DialogFooter className="flex flex-col sm:flex-row sm:justify-between sm:space-x-2">
            <Button 
              variant="outline" 
              onClick={() => setTermsModalOpen(false)}
              className="mb-2 sm:mb-0"
            >
              Fechar
            </Button>
            
            <Button 
              onClick={() => {
                form.setValue('terms', true);
                setTermsModalOpen(false);
              }}
            >
              Aceitar Termos
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Modal de Política de Privacidade */}
      <Dialog open={privacyModalOpen} onOpenChange={setPrivacyModalOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold flex items-center">
              <ShieldCheck className="h-6 w-6 mr-2 text-primary" />
              Política de Privacidade
            </DialogTitle>
            <DialogDescription>
              Como cuidamos de seus dados pessoais.
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="flex-1 pr-4 my-6">
            <div className="prose prose-gray max-w-none">
              <h3>1. Introdução</h3>
              <p>
                A privacidade dos nossos usuários é extremamente importante para nós. Esta Política de Privacidade descreve como coletamos, usamos, processamos e protegemos suas informações pessoais quando você usa o serviço Meu Preço Certo.
              </p>
              
              <h3>2. Informações que coletamos</h3>
              <p>
                Podemos coletar os seguintes tipos de informações:
              </p>
              <ul>
                <li><strong>Informações de cadastro:</strong> nome, e-mail, senha e outros dados fornecidos durante o registro.</li>
                <li><strong>Dados de uso:</strong> como você interage com nosso serviço, preferências e configurações.</li>
                <li><strong>Dados de negócio:</strong> informações sobre produtos, serviços, preços, custos e margens que você insere no sistema.</li>
                <li><strong>Informações técnicas:</strong> endereço IP, tipo de navegador, dispositivo e sistema operacional.</li>
              </ul>
              
              <h3>3. Como usamos suas informações</h3>
              <p>
                Utilizamos suas informações para:
              </p>
              <ul>
                <li>Fornecer, manter e melhorar nossos serviços</li>
                <li>Personalizar sua experiência</li>
                <li>Processar transações e pagamentos</li>
                <li>Enviar comunicações relacionadas ao serviço</li>
                <li>Detectar e prevenir atividades fraudulentas</li>
                <li>Cumprir obrigações legais</li>
              </ul>
              
              <h3>4. Compartilhamento de informações</h3>
              <p>
                Não compartilhamos suas informações pessoais com terceiros, exceto nas seguintes circunstâncias:
              </p>
              <ul>
                <li>Com seu consentimento explícito</li>
                <li>Com prestadores de serviços que nos auxiliam (processadores de pagamento, serviços de hospedagem)</li>
                <li>Para cumprir obrigações legais</li>
                <li>Em caso de reorganização empresarial (fusão, aquisição)</li>
              </ul>
              
              <h3>5. Segurança de dados</h3>
              <p>
                Implementamos medidas de segurança técnicas e organizacionais para proteger suas informações contra acesso não autorizado, perda ou alteração. No entanto, nenhum método de transmissão pela Internet ou armazenamento eletrônico é 100% seguro.
              </p>
              
              <h3>6. Seus direitos</h3>
              <p>
                De acordo com as leis de proteção de dados aplicáveis, você pode ter os seguintes direitos:
              </p>
              <ul>
                <li>Acessar suas informações pessoais</li>
                <li>Corrigir informações imprecisas</li>
                <li>Excluir suas informações (em determinadas circunstâncias)</li>
                <li>Restringir ou se opor ao processamento</li>
                <li>Portar seus dados para outro serviço</li>
                <li>Retirar o consentimento a qualquer momento</li>
              </ul>
              
              <h3>7. Cookies e tecnologias similares</h3>
              <p>
                Utilizamos cookies e tecnologias semelhantes para melhorar sua experiência, analisar o tráfego e personalizar o conteúdo. Você pode controlar o uso de cookies através das configurações do seu navegador.
              </p>
              
              <h3>8. Alterações nesta política</h3>
              <p>
                Podemos atualizar esta Política de Privacidade periodicamente. Notificaremos você sobre alterações significativas publicando a nova política em nosso site ou enviando um e-mail.
              </p>
              
              <h3>9. Contato</h3>
              <p>
                Se você tiver dúvidas sobre esta Política de Privacidade ou sobre nossas práticas de dados, entre em contato conosco pelo e-mail: contato@meuprecocerto.com.br
              </p>
            </div>
          </ScrollArea>
          
          <DialogFooter className="flex flex-col sm:flex-row sm:justify-between sm:space-x-2">
            <Button 
              variant="outline" 
              onClick={() => setPrivacyModalOpen(false)}
              className="mb-2 sm:mb-0"
            >
              Fechar
            </Button>
            
            <Button 
              onClick={() => {
                form.setValue('terms', true);
                setPrivacyModalOpen(false);
              }}
            >
              Aceitar Política
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}