import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Abordagem simplificada sem scripts inline no HTML

createRoot(document.getElementById("root")!).render(<App />);
