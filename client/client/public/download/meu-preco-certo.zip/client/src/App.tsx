import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { SearchProvider } from "@/components/Header";
import { NotificationProvider } from "@/context/NotificationContext";
import { AuthProvider } from "@/hooks/use-auth";
import { useState, useEffect } from "react";

// Layout persistente
import PersistentLayout from "@/components/PersistentLayout";

// Landing Page
import LandingPageWrapper from "./pages/landing/LandingPage";

// Login e Splash
import SplashScreen from "@/pages/splash";
import LoginPage from "@/pages/login";
import SignupPage from "@/pages/login/signup";
import ForgotPasswordPage from "@/pages/login/forgot-password";  // Página de recuperação de senha

// Páginas da aplicação
import DashboardPage from "@/pages/dashboard";
import PrecificacaoNovosPage from "@/pages/precificacao/novos";
import PrecificacaoNovosUnitarioPage from "@/pages/precificacao/novos/unitario";
import PrecificacaoNovosImportacaoPage from "@/pages/precificacao/novos/importacao";
import PrecificacaoServicosPage from "@/pages/precificacao/servicos";
import PrecificacaoServicosUnitarioPage from "@/pages/precificacao/servicos/unitario";
import PrecificacaoServicosImportacaoPage from "@/pages/precificacao/servicos/importacao";
import PrecificacaoUsadosPage from "@/pages/precificacao/usados";
import PrecificacaoUsadosUnitarioPage from "@/pages/precificacao/usados/unitario";
import PrecificacaoUsadosImportacaoPage from "@/pages/precificacao/usados/importacao";
import PrecificacaoAlugueisPage from "@/pages/precificacao/alugueis";
import PrecificacaoAlugueisUnitarioPage from "@/pages/precificacao/alugueis/unitario";
import PrecificacaoAlugueisImportacaoPage from "@/pages/precificacao/alugueis/importacao";
import CadastroProdutosPage from "@/pages/cadastros/produtos";
import CadastroFornecedoresPage from "@/pages/cadastros/fornecedores";
import CadastroCategoriasPage from "@/pages/cadastros/categorias";
import CadastroItensAluguelPage from "@/pages/cadastros/alugueis";
import CadastroServicosPage from "@/pages/cadastros/servicos";
import CadastroCustosPage from "@/pages/cadastros/custos";
import CadastroDespesasPage from "@/pages/cadastros/despesas";
import CadastroTaxasPage from "@/pages/cadastros/taxas";
import CadastroTributacoesPage from "@/pages/cadastros/tributacoes";
import CadastroRateiosPage from "@/pages/cadastros/rateios";
import ClientesPage from "@/pages/cadastros/clientes";
import CadastroPromocoesPage from "@/pages/cadastros/promocoes";
import MinhaContaPage from "@/pages/conta";
import NotificacoesPage from "@/pages/notificacoes";
import PlanosEUpgradesPage from "@/pages/planos";
import TreinamentosPage from "@/pages/treinamentos";
import SuportePage from "@/pages/suporte";
import NotFound from "@/pages/not-found";

// Componente para renderizar as rotas autenticadas dentro do layout persistente
function AuthenticatedRoutes() {
  return (
    <PersistentLayout>
      <Switch>
        <Route path="/dashboard" component={DashboardPage} />
        
        {/* Precificação Routes */}
        <Route path="/precificacao/novos" component={PrecificacaoNovosPage} />
        <Route path="/precificacao/novos/unitario" component={PrecificacaoNovosUnitarioPage} />
        <Route path="/precificacao/novos/importacao" component={PrecificacaoNovosImportacaoPage} />
        <Route path="/precificacao/servicos" component={PrecificacaoServicosPage} />
        <Route path="/precificacao/servicos/unitario" component={PrecificacaoServicosUnitarioPage} />
        <Route path="/precificacao/servicos/importacao" component={PrecificacaoServicosImportacaoPage} />
        <Route path="/precificacao/usados" component={PrecificacaoUsadosPage} />
        <Route path="/precificacao/usados/unitario" component={PrecificacaoUsadosUnitarioPage} />
        <Route path="/precificacao/usados/importacao" component={PrecificacaoUsadosImportacaoPage} />
        <Route path="/precificacao/alugueis" component={PrecificacaoAlugueisPage} />
        <Route path="/precificacao/alugueis/unitario" component={PrecificacaoAlugueisUnitarioPage} />
        <Route path="/precificacao/alugueis/importacao" component={PrecificacaoAlugueisImportacaoPage} />
        
        {/* Cadastros Routes */}
        <Route path="/cadastros/produtos" component={CadastroProdutosPage} />
        <Route path="/cadastros/fornecedores" component={CadastroFornecedoresPage} />
        <Route path="/cadastros/categorias" component={CadastroCategoriasPage} />
        <Route path="/cadastros/alugueis" component={CadastroItensAluguelPage} />
        <Route path="/cadastros/servicos" component={CadastroServicosPage} />
         <Route path="/cadastros/custos" component={CadastroCustosPage} />
        <Route path="/cadastros/clientes" component={ClientesPage} />
        <Route path="/cadastros/despesas" component={CadastroDespesasPage} />
        <Route path="/cadastros/taxas" component={CadastroTaxasPage} />
        <Route path="/cadastros/tributacoes" component={CadastroTributacoesPage} />
        <Route path="/cadastros/rateios" component={CadastroRateiosPage} />
        <Route path="/cadastros/promocoes" component={CadastroPromocoesPage} />
        
        {/* Notificações */}
        <Route path="/notificacoes" component={NotificacoesPage} />
        
        {/* Planos e Upgrades */}
        <Route path="/planos-e-upgrades" component={PlanosEUpgradesPage} />
        
        {/* Minha Conta */}
        <Route path="/minha-conta" component={MinhaContaPage} />
        
        {/* Treinamentos */}
        <Route path="/treinamentos" component={TreinamentosPage} />
        
        {/* Suporte */}
        <Route path="/suporte" component={SuportePage} />
        
        <Route component={NotFound} />
      </Switch>
    </PersistentLayout>
  );
}

// Componente para gerenciar autenticação e splash screen
function Router() {
  const [showSplash, setShowSplash] = useState(true);
  const [initialRoute, setInitialRoute] = useState<string | null>(null);
  const [location, navigate] = useLocation();

  useEffect(() => {
    // Capturar a rota inicial para preservá-la
    const currentPath = window.location.pathname;
    
    // Se não estamos em uma rota de autenticação e não é o root, salvamos para redirecionamento após login
    if (!['/acessar', '/cadastre-se', '/recuperar', '/'].includes(currentPath)) {
      localStorage.setItem('lastPath', currentPath);
    }
    
    setInitialRoute(currentPath);

    // Não mostrar splash se for uma navegação para planos-e-upgrades
    if (currentPath === '/planos-e-upgrades') {
      setShowSplash(false);
      return;
    }

    // Tempo padrão para a splash screen
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  if (showSplash) {
    return <SplashScreen />;
  }

  // Para rotas de autenticação, não usamos o layout persistente
  const isAuthRoute = ['/acessar', '/cadastre-se', '/recuperar', '/'].includes(location);
  
  if (isAuthRoute) {
    return (
      <Switch>
        <Route path="/" component={LandingPageWrapper} />
        <Route path="/acessar" component={LoginPage} />
        <Route path="/cadastre-se" component={SignupPage} />
        <Route path="/recuperar" component={ForgotPasswordPage} />
        <Route component={() => <AuthenticatedRoutes />} />
      </Switch>
    );
  }

  // Para rotas autenticadas, usamos o layout persistente
  return <AuthenticatedRoutes />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <NotificationProvider>
          <SearchProvider>
            <Router />
            <Toaster />
          </SearchProvider>
        </NotificationProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;