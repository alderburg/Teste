import { useState, useEffect, ReactNode } from "react";
import { useLocation } from "wouter";
import StaticSidebar from "./StaticSidebar";
import Header from "./Header";

interface PersistentLayoutProps {
  children: ReactNode;
}

export default function PersistentLayout({ children }: PersistentLayoutProps) {
  // Definimos o estado inicial do sidebar como fechado por padrão, sempre
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarMinimized, setSidebarMinimized] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  // Usar o location para monitorar mudanças de rota
  const [location] = useLocation();

  // Detectar se é dispositivo móvel
  useEffect(() => {
    // Recuperar estado do sidebar do localStorage, se disponível
    const savedSidebarMinimized = localStorage.getItem('sidebarMinimized');
    if (savedSidebarMinimized) {
      setSidebarMinimized(JSON.parse(savedSidebarMinimized));
    }

    const checkIfMobile = () => {
      const isMobileView = window.innerWidth < 768;
      setIsMobile(isMobileView);
      
      // Em dispositivos móveis, garantimos que o menu inicie fechado
      if (isMobileView) {
        setSidebarOpen(false);
      }
    };
    
    checkIfMobile();
    window.addEventListener('resize', checkIfMobile);
    
    return () => {
      window.removeEventListener('resize', checkIfMobile);
    };
  }, []);

  // Salvar estado do sidebar no localStorage quando mudar
  useEffect(() => {
    localStorage.setItem('sidebarMinimized', JSON.stringify(sidebarMinimized));
  }, [sidebarMinimized]);
  
  // Efeito para rolar para o topo quando a rota muda
  useEffect(() => {
    // Quando a location (rota) mudar, rolamos a página para o topo
    window.scrollTo(0, 0);
    
    // Também rolar o container principal para o topo
    const mainElement = document.querySelector('main');
    if (mainElement) {
      mainElement.scrollTop = 0;
    }
  }, [location]);

  const toggleSidebar = () => {
    if (isMobile) {
      // Em mobile, abre/fecha completamente a sidebar
      setSidebarOpen(prevState => {
        const newState = !prevState;
        
        // Removido o código para disparar eventos customizados
        
        return newState;
      });
    } else {
      // Em desktop, minimiza/maximiza a sidebar
      setSidebarMinimized(prevState => !prevState);
    }
  };
  
  // Esta função agora está vazia, mas mantemos compatibilidade com interface
  const minimizeSidebar = () => {};

  // Aplicamos um estilo de transição apenas nos elementos que realmente mudam,
  // não no container principal para evitar re-renderizações desnecessárias
  return (
    <div className="relative min-h-screen bg-gray-100">
      {/* Sempre renderizamos o sidebar, mesmo em mobile. A visibilidade será controlada por classes CSS */}
      <StaticSidebar 
        isOpen={sidebarOpen} 
        isMinimized={sidebarMinimized} 
        toggleSidebar={toggleSidebar}
        minimizeSidebar={minimizeSidebar}
        isMobile={isMobile}
      />
      
      <div 
        className={`transition-all duration-100 ease-out ${isMobile && sidebarOpen ? 'opacity-50' : ''}`}
        style={{ 
          marginLeft: !isMobile ? (sidebarMinimized ? '5rem' : '16rem') : '0',
          minHeight: '100vh',
          width: 'auto'
        }}
      >
        <Header toggleSidebar={toggleSidebar} isMinimized={sidebarMinimized} />
        
        <main className="w-full overflow-auto p-2 sm:p-4 md:p-6 pt-16 md:pt-20 bg-gray-100">
            <div className="pb-6">
                {children}
            </div>
        </main>
      </div>
      
      {/* Overlay para fechar o sidebar em dispositivos móveis */}
      {sidebarOpen && isMobile && (
        <div
          className="fixed inset-0 z-20 bg-black bg-opacity-50 transition-opacity md:hidden"
          onClick={toggleSidebar}
        />
      )}
    </div>
  );
}